# Favorite API
Persists favorite information for multiple application sections.

Currently supported:
  - report-package-templates


# Installation dependencies

- install mongo
- add this line to your hosts file: 
  127.0.0.1       mongo
- run this script to add api-services user onto mongo (for event notifications dependency)
  http://petvstfs01:8080/tfs/DefaultCollection/SIRNG/SIRNG%20Team/_git/RAAS#path=%2Fapi-services%2Fdb%2Fusers.js&version=GBmaster&_a=contents
  


# Run the server

```

$ npm install

$ API_SERVICES_URI=http://10.97.113.13 \
  TARGET_URI=http://localhost:1111 \
  ADP_ENV=dev \
  CONSUL_URI=petvsdevnginx1.ad.esi.adp.com \
  PORT=1111 \
  npm start
  
```

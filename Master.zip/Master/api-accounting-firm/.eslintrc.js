module.exports = {
  "extends": "airbnb",
  "parser": "babel-eslint",
  "env": {
    "browser": true,
    "es6": true,
    "node": true,
    "mocha": true
  },

  "ecmaFeatures": {
    "modules": true,
    "jsx": false
  },

  "settings": {
    "ecmascript": 6,
    "jsx": false
  },

  "rules": {
    "indent": [1, 2, {"SwitchCase": 1}],
    "comma-dangle": [2, "never"],
    "strict": 0,
    "max-len": 0,
    "prefer-template": 0,
    "no-unused-expressions": 0,
    "prefer-arrow-callback": 0,
    "func-names": 0,
    "new-cap": [2, {"capIsNewExceptions": ["Radium"]}]
  }
};

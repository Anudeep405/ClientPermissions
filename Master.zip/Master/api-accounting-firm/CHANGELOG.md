<a name="0.0.58"></a>
## [0.0.58](http://petvstfs01:8080//compare/v0.0.57...v0.0.58) (2017-05-04)


### Fix

* A 204 GET should not log an error message ([1394faf79295155411908906215bd23382322743](http://petvstfs01:8080//commits/1394faf79295155411908906215bd23382322743))
* Compatibility with node4 ([9e9f44abc123e11935594af3f72fc1d7d218f898](http://petvstfs01:8080//commits/9e9f44abc123e11935594af3f72fc1d7d218f898))
* Remove extraneous deps from shrinkwrap ([23e556597fed2269dd6d3039270888733fd059cb](http://petvstfs01:8080//commits/23e556597fed2269dd6d3039270888733fd059cb))

### Update

* Include invitationID in error logs ([b15d4e4d739ccccb0a7f660a9371344ad25bd534](http://petvstfs01:8080//commits/b15d4e4d739ccccb0a7f660a9371344ad25bd534))
* Standardize logging messages and provide more info  ([08911c205fd4fbf4f92df962fad92bcea70bac0a](http://petvstfs01:8080//commits/08911c205fd4fbf4f92df962fad92bcea70bac0a))



<a name="0.0.57"></a>
## [0.0.57](http://petvstfs01:8080//compare/v0.0.55...v0.0.57) (2017-04-26)




<a name="0.0.55"></a>
## [0.0.55](http://petvstfs01:8080//compare/v0.0.54...v0.0.55) (2017-04-21)




<a name="0.0.54"></a>
## [0.0.54](http://petvstfs01:8080//compare/v0.0.53...v0.0.54) (2017-04-20)




<a name="0.0.53"></a>
## [0.0.53](http://petvstfs01:8080//compare/301636bf19abc7423f2d9762d4d0e3092718a7da...v0.0.53) (2017-04-20)


### Feature

* does not invite CPAs ([ea87b7720e5822657f5bd7409961110722da17d4](http://petvstfs01:8080//commits/ea87b7720e5822657f5bd7409961110722da17d4))

### Fix

* Client could accept someone else's invitation ([53c314fccf43b520e644eb5a0b7afe784572037b](http://petvstfs01:8080//commits/53c314fccf43b520e644eb5a0b7afe784572037b))
* Crashing exception on RequestApi.js when error was returned ([e696304806bd186a9d08bb5e0be11a75147fe42a](http://petvstfs01:8080//commits/e696304806bd186a9d08bb5e0be11a75147fe42a))
* exception missing mongodb dep ([2e4fc5e0b0cdc49ec2106043ad01ed6ff20d6bb0](http://petvstfs01:8080//commits/2e4fc5e0b0cdc49ec2106043ad01ed6ff20d6bb0))
* GET Client Invitations sorting ([eff48c86efab0ac71794ad6e913fb9171d460cfe](http://petvstfs01:8080//commits/eff48c86efab0ac71794ad6e913fb9171d460cfe))
* incorrect package name ([301636bf19abc7423f2d9762d4d0e3092718a7da](http://petvstfs01:8080//commits/301636bf19abc7423f2d9762d4d0e3092718a7da))
* must create invitation if IID is not found ([bee00d24690067b38750a214b0e6fbcfebb3a07e](http://petvstfs01:8080//commits/bee00d24690067b38750a214b0e6fbcfebb3a07e))
* Should not be able to accept expired invitations ([5163790db37b0b2f812e4d96016669650b1eaeb9](http://petvstfs01:8080//commits/5163790db37b0b2f812e4d96016669650b1eaeb9))
* unit tests for GET invitations ([1ab0b057fac8092ab8d69cceb7c8dc05f2a9b7ac](http://petvstfs01:8080//commits/1ab0b057fac8092ab8d69cceb7c8dc05f2a9b7ac))
* unit tests for GET invitations ([9a2c0f911b6773d486201c4704af915672fee2aa](http://petvstfs01:8080//commits/9a2c0f911b6773d486201c4704af915672fee2aa))

### GET

* Get All Client Invitations - push basic request and respond with sample json data ([0c1dd001102d5ce318c82ec786bc228cb5c0070d](http://petvstfs01:8080//commits/0c1dd001102d5ce318c82ec786bc228cb5c0070d))
* Get Client Invitations - add the Use Case with the parameter for a single invitation ([65e24ba62d3ea893766e327d2398fc7730af61b5](http://petvstfs01:8080//commits/65e24ba62d3ea893766e327d2398fc7730af61b5))

### Update

* Adds DB sample for ApiAccountingFirmClientInvitations ([6c94a25ca60e9426ab83801ea620c7d22e7ee852](http://petvstfs01:8080//commits/6c94a25ca60e9426ab83801ea620c7d22e7ee852))
* Adds legal api acceptance tests ([a9459fb4e1ff70267a7c44e051cc392cb627c4f8](http://petvstfs01:8080//commits/a9459fb4e1ff70267a7c44e051cc392cb627c4f8))
* adds name fields to client, company and cpa ([7ffdc93be7adc06e78917d1a9f9191c6c4ff954f](http://petvstfs01:8080//commits/7ffdc93be7adc06e78917d1a9f9191c6c4ff954f))
* Better integration tests for invalid fein/iid ([68572c828f2c3a728cb99642b6e61f4fd322527a](http://petvstfs01:8080//commits/68572c828f2c3a728cb99642b6e61f4fd322527a))
* bumps ngcoreapi-bootstrap ([eb396860f63af5198e4452b7632d2d07acbaf85a](http://petvstfs01:8080//commits/eb396860f63af5198e4452b7632d2d07acbaf85a))
* DB sample now also holds information for the firm ([50e0cec28d425c76686fc539206909d39f0e9495](http://petvstfs01:8080//commits/50e0cec28d425c76686fc539206909d39f0e9495))
* enables accept tests ([83979cd2c678f257d028090cdeef88646bfc653c](http://petvstfs01:8080//commits/83979cd2c678f257d028090cdeef88646bfc653c))
* Fixes integration tests remove accountant API call ([3c8fea68abaa5fa5bbddbd3f2b2baa5ab06e12e1](http://petvstfs01:8080//commits/3c8fea68abaa5fa5bbddbd3f2b2baa5ab06e12e1))
* Forces client list to refresh for every invitation.create ([a93c543dad32d04718597133486ef46500037b91](http://petvstfs01:8080//commits/a93c543dad32d04718597133486ef46500037b91))
* improvements on RequestApi ([092d30a51b78e3d7e7dc0914d00f33ab0b169d5e](http://petvstfs01:8080//commits/092d30a51b78e3d7e7dc0914d00f33ab0b169d5e))
* Increases integration test coverage ([bc76602bdab434be0bcd95dff3e50a2d01abbb69](http://petvstfs01:8080//commits/bc76602bdab434be0bcd95dff3e50a2d01abbb69))
* Integration tests ([97098e70cf937ce5846a7fed3cb1cf6f8923f0a0](http://petvstfs01:8080//commits/97098e70cf937ce5846a7fed3cb1cf6f8923f0a0))
* Integration tests ([f5fc1ef42bfed59de4174c3130927af47822e488](http://petvstfs01:8080//commits/f5fc1ef42bfed59de4174c3130927af47822e488))
* Integration tests ([fb5ebc0ed8f4f39f97ff54a459f3900672bbf674](http://petvstfs01:8080//commits/fb5ebc0ed8f4f39f97ff54a459f3900672bbf674))
* integration tests to use npm mdule ([75880d8c9a13e3505936fa044a11f8efcf079847](http://petvstfs01:8080//commits/75880d8c9a13e3505936fa044a11f8efcf079847))
* ngcoreapi-bootstrap upgrade ([3e42b2324f9d7a2d3be8d713ff726b277e0f84d2](http://petvstfs01:8080//commits/3e42b2324f9d7a2d3be8d713ff726b277e0f84d2))
* puts mongodb dependency back ([e7113c0e9e2a2cb7517b03a6a2cf2a89dbf4c2c8](http://petvstfs01:8080//commits/e7113c0e9e2a2cb7517b03a6a2cf2a89dbf4c2c8))
* remove console.log ([713e6f55902ac0020b75c0fa9aa61b8acf254d6f](http://petvstfs01:8080//commits/713e6f55902ac0020b75c0fa9aa61b8acf254d6f))
* remove console.log ([c06bfd340e76307d93e765115f668b43f0213b50](http://petvstfs01:8080//commits/c06bfd340e76307d93e765115f668b43f0213b50))
* remove console.log ([28e880e2904142ac29f42bc8073717ae524ca08b](http://petvstfs01:8080//commits/28e880e2904142ac29f42bc8073717ae524ca08b))
* removes mongodb dependency ([624704806d5b7ca5780f1f40ce17982fa3557e22](http://petvstfs01:8080//commits/624704806d5b7ca5780f1f40ce17982fa3557e22))
* removes mongodb dependency ([1defe4e23c93e12d559b4f2c95b3e5ce59caa37a](http://petvstfs01:8080//commits/1defe4e23c93e12d559b4f2c95b3e5ce59caa37a))
* removes objectID hard depdnency ([0f767148b2718c1b012b5653d753639c43b9e13c](http://petvstfs01:8080//commits/0f767148b2718c1b012b5653d753639c43b9e13c))
* removes package.json mongodb dependency ([36d4ab629e43cc803088604fd3aad703333c496e](http://petvstfs01:8080//commits/36d4ab629e43cc803088604fd3aad703333c496e))
* renames Invitations collection to comply with standards ([eddef21c95594273247cf9ab68e1e159da568996](http://petvstfs01:8080//commits/eddef21c95594273247cf9ab68e1e159da568996))
* renames Invitations collection to comply with standards ([7f821eeac673949f67ce4b10f0afe3a2a631b54d](http://petvstfs01:8080//commits/7f821eeac673949f67ce4b10f0afe3a2a631b54d))
* replaces api-bootstrap for ngcoreapi-bootstrap ([e19e135b35cac76512388e05f02bbc8e77f30710](http://petvstfs01:8080//commits/e19e135b35cac76512388e05f02bbc8e77f30710))
* simpler random tos code names ([57ed5a41aeec01a15c5b703698ee9ad70740aac8](http://petvstfs01:8080//commits/57ed5a41aeec01a15c5b703698ee9ad70740aac8))
* simpler tosCode names ([da3a6674a7beda42382f87937493083408b8b348](http://petvstfs01:8080//commits/da3a6674a7beda42382f87937493083408b8b348))
* some optimizations ([80470bc58819060e4816026893693ca3df069271](http://petvstfs01:8080//commits/80470bc58819060e4816026893693ca3df069271))
* tests invitation order by invitationID ([5b3c8a7f421920208e0298601aee3a67af15ca07](http://petvstfs01:8080//commits/5b3c8a7f421920208e0298601aee3a67af15ca07))
* Tests that accepted invitation has the correct statusCode ([cca4f405dc88c63849080bced7e0ff56358b0eaf](http://petvstfs01:8080//commits/cca4f405dc88c63849080bced7e0ff56358b0eaf))
* Unit test fixes ([e33aae6aba29660f026a6b778b0543b646c85d10](http://petvstfs01:8080//commits/e33aae6aba29660f026a6b778b0543b646c85d10))
* US558644 transactionID logger ([39eaf569df39cf61fc4748aa1bd71c6ff5bb8c06](http://petvstfs01:8080//commits/39eaf569df39cf61fc4748aa1bd71c6ff5bb8c06))




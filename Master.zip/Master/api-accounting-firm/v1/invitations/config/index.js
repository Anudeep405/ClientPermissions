'use strict';

module.exports = class Config {

  constructor(globalConfig) {
    this.ACCOUNTING_FIRM_COLLECTION = 'ApiAccountingFirmClientInvitations';
    this.INVITATION_EXPIRE_DAY = 7;
    this.INVITATION_REMIND_DAY = 3;

    let apiServicesHost;
    if (globalConfig) {
      apiServicesHost = globalConfig.endpoints.apiServices;
    }
    this.API_SERVICES_HOST = (process.env.API_SERVICES_URI || process.env.TARGET_URI || apiServicesHost) + '/i/api/';
    this.API_HOST = (process.env.TARGET_URI || apiServicesHost) + '/i/api/';

    this.INVITATIONS_LIST_API_PATH = 'accounting-firm/v1/client-access-invitations';
    this.INVITATIONS_LIST_API_URL = this.API_HOST + this.INVITATIONS_LIST_API_PATH;
    this.INVITATION_BY_INVITATIONID_API_PATH = 'accounting-firm/v1/client-access-invitations/:invitationid';
    this.INVITATION_BY_INVITATIONID_URL = this.API_HOST + this.INVITATION_BY_INVITATIONID_API_PATH;

    this.INVITATION_CREATE_API_PATH = 'events/accounting-firm/v1/client-access-invitation.create';
    this.INVITATION_CREATE_API_URL = this.API_HOST + this.INVITATION_CREATE_API_PATH;

    this.INVITATION_ACCEPT_API_PATH = 'events/accounting-firm/v1/client-access-invitation.accept';
    this.INVITATION_ACCEPT_API_URL = this.API_HOST + this.INVITATION_ACCEPT_API_PATH;

    this.INVITATION_REJECT_API_PATH = 'events/accounting-firm/v1/client-access-invitation.reject';
    this.INVITATION_REJECT_API_URL = this.API_HOST + this.INVITATION_REJECT_API_PATH;


    this.NOTIFICATION_EMAIL_SEND_API_URL = this.API_SERVICES_HOST + 'events/notification/v1/emails.send';

    this.GET_ORGOID_BY_IID_API_URL = this.API_SERVICES_HOST + 'company/v1/orgoid/iid/:iid?installationGroup=runcomplete';
    this.GET_ORGOID_BY_FEIN_API_URL = this.API_SERVICES_HOST + 'company/v1/orgoid/fein/:fein';

    this.GET_CLIENTS_BY_ORGOID_API_URL = this.API_SERVICES_HOST + 'company/v1/clients/:orgoid';
    this.GET_CLIENTS_API_URL = this.API_SERVICES_HOST + 'company/v1/clients';
    this.GET_CONTACTS_BY_ORGOID_API_URL = this.API_SERVICES_HOST + 'company/v1/company-contacts/:orgoid';
    this.GET_FIRM_BY_ORGOID_API_URL = this.API_SERVICES_HOST + 'company/v1/company-addresses/:orgoid';
    this.GET_FIRM_SERVICE_REGION_BY_ORGOID_API_URL = this.API_SERVICES_HOST + 'accountant-connect/v1/support-contacts/orgoid/:orgoid';
    this.GET_FIRM_INFO_API_URL = this.API_SERVICES_HOST + 'company/v1/company-info';

    this.ADD_ACCOUNTANT_API_PATH = 'events/company/v1/accountant.add';
    this.ADD_ACCOUNTANT_API_URL = this.API_SERVICES_HOST + this.ADD_ACCOUNTANT_API_PATH;

    this.GET_USER_CONTACTS_BY_ORGOID_API_URL = this.API_SERVICES_HOST + 'account-management/v1/user-contacts/:orgoid';

    this.ACCEPT_LEGAL_API_URL = this.API_SERVICES_HOST + 'events/legal/v1/tos.accept';

    this.GET_TOS_ACCEPTED_URL = this.API_SERVICES_HOST + '/legal/v1/tos-accepted/orgoid/:orgoid/associateoid/:aoid';
  }
};

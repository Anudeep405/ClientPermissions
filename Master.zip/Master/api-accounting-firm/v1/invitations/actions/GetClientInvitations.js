'use strict';

module.exports = class GetClientInvitations {
  constructor(deps) {
    this.logger = deps.logger;
    this.deps = deps;
    this.mongoRepo = deps.mongoRepo;
    this.objectID = deps.mongodb.ObjectID;
    this.invitationsCollection = deps.config.ACCOUNTING_FIRM_COLLECTION;
  }

  run(params) {
    // const associateOID = params.associateOID;
    const organizationOID = params.organizationOID;
    const invitationID = params.invitationid;

    return new Promise((resolve, reject) => {
      // const logger = this.deps.logger;
      // const collection = null;

      const matchKeys = {};
      const orKeys = {};

      if (organizationOID) {
        matchKeys['actor.organizationOID'] = organizationOID;
        orKeys['invitation.client.organizationOID'] = organizationOID;
      }
      if (invitationID) {
        const _id = this.objectID.isValid(invitationID) ? this.objectID(invitationID) : invitationID;
        matchKeys._id = _id;
        orKeys._id = _id;
      }

      const projectKeys = {
        _id: false,
        invitationID: '$_id',
        creationDateTime: '$invitation.creationDateTime',
        dueDateTime: '$invitation.dueDateTime',
        responseDateTime: '$invitation.responseDateTime',
        invitationLabel: '$invitation.invitationLabel',
        invitationStatusCode: '$invitation.invitationStatusCode',
        grantedAccessPermissions: '$invitation.grantedAccessPermissions',
        requestedAccessPermissions: '$invitation.requestedAccessPermissions',
        'client.iid': '$invitation.client.iid',
        'client.fein': '$invitation.client.fein',
        'client.legalName': '$invitation.client.legalNameAtTimeOfResponse',
        'firm.organizationOID': '$invitation.firm.organizationOID',
        'firm.legalName': '$invitation.firm.legalNameAtTimeOfRequest',
        searchFields: '$invitation.searchFields',
        'responseActor.formattedName': '$invitation.responseActor.formattedName',
        'responseActor.associateOID': '$invitation.responseActor.associateOID',
        'responseActor.organizationOID': '$invitation.responseActor.organizationOID',
        'requestActor.formattedName': '$actor.formattedName',
        'requestActor.associateOID': '$actor.associateOID',
        'requestActor.organizationOID': '$actor.organizationOID',
        invitationMessage: '$invitation.invitationMessage'
      };
      const aggregateKeys = [{
        $match: { $or: [matchKeys, orKeys] }
      }, {
        $sort: {
          _id: -1
        }
      }, {
        $limit: 100
      }, {
        $project: projectKeys
      }];

      this.mongoRepo.collection(this.invitationsCollection)
        .then(collection => {
          collection.aggregate(aggregateKeys, (error, result) => {
            if (error) {
              this.logger.error(`file="GetClientInvitationsAction" msg="Error returned by Mongo" error="${error.message}"`);
              return reject(500);
            } else if (result && result[0]) {
              return resolve(result);
            }
            return resolve(); // resolve with nothing in it does a 204
          });
        })
        .catch(error => {
          this.logger.error(`file="GetClientInvitationsAction" msg="Error accessing Mongo collection" error="${(error || {}).message}"`);
          return reject(500);
        });
    });
  }
  /*
   copyObject(dbObj) {
   let newObj = JSON.parse(JSON.stringify(responseFormatted.invitations[0]));  //cloning

   for (var key in newObj) {
   //initialize all the fields
   newObj[key] = '';
   }

   for (var key in dbObj.invitation) {
   //copy all the fields
   newObj[key] = dbObj.invitation[key];
   }
   newObj['invitationID'] = dbObj['_id'];

   const dueDate = new Date(dbObj.invitation.dueDateTime);
   const today = new Date();

   if (dueDate < today && dbObj.invitation.invitationStatusCode.codeValue == 'open')
   {
   newObj.invitationStatusCode['codeValue'] = 'expired';
   }

   // return JSON.stringify(newObj);
   return newObj;
   }
   */
};

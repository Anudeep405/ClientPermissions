'use strict';

module.exports = class SendReminderInvitations {
  constructor(deps) {
    this.logger = deps.logger;
    this.NOTIFICATION_EMAIL_SEND_API_URL = deps.config.NOTIFICATION_EMAIL_SEND_API_URL;
    this.REMAINING_INVITATION_EXPIRE_DAY = deps.config.INVITATION_EXPIRE_DAY - deps.config.INVITATION_REMIND_DAY;
    this.requestApi = deps.requestApi;
  }

  run(para) {
    return new Promise((resolve, reject) => {
      if (!para) {
        return reject(500);
      }
      let index = 0;
      const sendEmail = (requestApi, invitationID, remainingDays, emailAPIURL, actor,
                         emailInvitationBody, recipients, emailBodyTemplate, emailSubject, callBack) => {
        const headers = {
          orgoid: actor.organizationOID,
          consumeraoid: actor.associateOID,
          associateoid: actor.associateOID,
          'content-type': 'application/json'
        };
        const reqBody = emailInvitationBody;
        reqBody.events[0].actor = actor;
        const emailBody = emailBodyTemplate.replace('%invitationID%', invitationID).replace('%expireDay%', remainingDays);

        const emails = [];
        if (recipients) {
          for (let i = 0; i < recipients.length; i++) {
            emails.push({ recipient: recipients[i], subject: emailSubject, body: emailBody });
          }
        } else {
          this.logger.error(`file="SendReminderInvitationsAction" msg="Email ID is not found" invitationID="${invitationID}"`);
          return callBack();
        }

        reqBody.events[0].data.transform.emails = emails;
        return requestApi.run(emailAPIURL, 'POST', headers, reqBody)
          .then(() => {
            callBack();
          })
          .catch((error) => {
            callBack(error);
          });
      };

      const sendEmails = () => {
        if (index < para.reminders.length) {
          const invitationID = para.reminders[index]._id;
          return sendEmail(
            this.requestApi,
            para.reminders[index]._id,
            this.REMAINING_INVITATION_EXPIRE_DAY,
            this.NOTIFICATION_EMAIL_SEND_API_URL,
            para.reminders[index].actor,
            para.emailInvitationBody,
            para.reminders[index].invitation.client.recipients,
            para.reminders[index].invitation.invitationEmail.body,
            'Invitation from your accountant is waiting for your approval',
            (error) => {
              if (error) {
                this.logger.error(`file="SendReminderInvitationsAction" msg="send email failed" invitationID="${invitationID}" error="${error}"`);
              }
              index++;
              this.logger.info(`file="SendReminderInvitationsAction" msg="sent reminder" invitationID="${invitationID}" index=${index}`);

              return sendEmails();
            }
          );
        }
        return resolve();
      };

      return sendEmails();
    });
  }
};

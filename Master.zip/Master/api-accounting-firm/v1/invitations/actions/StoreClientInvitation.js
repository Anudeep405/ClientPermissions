'use strict';

module.exports = class StoreClientInvitation {
  constructor(deps) {
    this.logger = deps.logger;
    this.mongoRepo = deps.mongoRepo;
    this.collectionName = deps.config.ACCOUNTING_FIRM_COLLECTION;
  }

  run(params) {
    const body = params.body;
    const uQuery = {
      'actor.organizationOID': body.actor.organizationOID,
      'actor.associateOID': body.actor.associateOID,
      'invitation.invitationStatusCode.codeValue': 'open'
    };
    if (body.invitation.client.iid) {
      uQuery['invitation.client.iid'] = body.invitation.client.iid;
    }
    if (body.invitation.client.fein) {
      uQuery['invitation.client.fein'] = body.invitation.client.fein;
    }

    return new Promise((resolve, reject) => {
      this.mongoRepo.collection(this.collectionName)
        .then(collection => {
          collection.update(uQuery, { $set: { 'invitation.invitationStatusCode.codeValue': 'closed' } }, { multi: true }, function (err) {
            if (err) {
              return reject(500);
            }
            return collection.insert(body, (error, result) => {
              if (error) {
                this.logger.error(`file="StoreClientInvitationAction" msg="Cannot insert record" error="${(error || {}).message}"`);
                return reject(500);
              }
              return resolve(result.ops[0]._id);
            });
          });
        })
        .catch((error) => {
          this.logger.error(`file="StoreClientInvitationAction" msg="Mongo collection error" error="${(error || {}).message}"`);
          return reject(500);
        });
    });
  }
};

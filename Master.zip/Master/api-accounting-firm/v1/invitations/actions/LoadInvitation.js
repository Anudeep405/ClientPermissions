'use strict';


module.exports = class GetInvitation {
  constructor(deps) {
    this.deps = deps;
    this.logger = this.deps.logger;
    this.mongoRepo = deps.mongoRepo;
    this.invitationsCollection = deps.config.ACCOUNTING_FIRM_COLLECTION;
    this.objectID = deps.mongodb.ObjectID;
  }

  run(invitationid, organizationOID) {
    return new Promise((resolve, reject) => {
      const now = (new Date()).toISOString();
      const query = {
        _id: this.objectID(invitationid),
        $or: [
          { 'actor.organizationOID': organizationOID },
          { 'invitation.client.organizationOID': organizationOID }
        ],
        'invitation.invitationStatusCode.codeValue': 'open',
        'invitation.dueDateTime': {
          $gt: now
        }
      };
      this.mongoRepo.collection(this.invitationsCollection)
        .then(collection => {
          collection.find(query, {}).toArray((error, result) => {
            if (error) {
              this.logger.error(`file="LoadInvitationAction" error="${error.message}"`);
              return reject(500);
            }
            if (result.length > 0) {
              resolve(result[0]);
            }
            return reject(404);
          });
        })
        .catch(error => {
          this.logger.error(`file="LoadInvitationAction" error="${(error || {}).message}"`);
          return reject(500);
        });
    });
  }
};


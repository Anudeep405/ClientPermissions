'use strict';

module.exports = class UpdateReminderInvitations {
  constructor(deps) {
    this.logger = deps.logger;
    this.mongoRepo = deps.mongoRepo;
    this.collectionName = deps.config.ACCOUNTING_FIRM_COLLECTION;
  }

  run(para) {
    const uQuery = {
      'invitation.reminder.dateTime': { $lte: para.dateTime },
      'invitation.reminder.isSend': false,
      'invitation.invitationStatusCode.codeValue': 'open'
    };
    const uSet = { $set: { 'invitation.reminder.isSend': true } };

    return new Promise((resolve, reject) => {
      this.mongoRepo.collection(this.collectionName)
        .then(collection => {
          collection.update(uQuery, uSet, { multi: true }, function (err, resData) {
            if (err) {
              this.logger.error(`file="UpdateReminderInvitationsAction" msg="Mongo collection update error" error="${(err || {}).message}"`);
              return reject(500);
            }
            return resolve(resData);
          });
        })
        .catch((error) => {
          this.logger.error(`file="UpdateReminderInvitationsAction" msg="Mongo collection error" error="${(error || {}).message}"`);
          return reject(500);
        });
    });
  }
};

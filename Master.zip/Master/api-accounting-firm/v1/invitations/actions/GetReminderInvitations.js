'use strict';

module.exports = class GetReminderInvitations {
  constructor(deps) {
    this.logger = deps.logger;
    this.mongoRepo = deps.mongoRepo;
    this.collectionName = deps.config.ACCOUNTING_FIRM_COLLECTION;
  }

  run(para) {
    const query = {
      'invitation.reminder.dateTime': { $lte: para.dateTime },
      'invitation.reminder.isSend': false,
      'invitation.invitationStatusCode.codeValue': 'open'
    };
    return new Promise((resolve, reject) => {
      this.mongoRepo.collection(this.collectionName)
        .then(collection => {
          collection.find(query, {}).toArray(function (err, resData) {
            if (err) {
              return reject(500);
            }
            return resolve(resData);
          });
        })
        .catch((error) => {
          this.logger.error(`file=GetReminderInvitationsAction" msg="Mongo collection error" error=${(error || {}).message}`);
          return reject(500);
        });
    });
  }
};

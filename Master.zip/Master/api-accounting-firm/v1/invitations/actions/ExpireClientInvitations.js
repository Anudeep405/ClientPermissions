'use strict';

module.exports = class ExpireClientInvitations {
  constructor(deps) {
    this.logger = deps.logger;
    this.deps = deps;
    this.mongoRepo = deps.mongoRepo;
    this.invitationsCollection = deps.config.ACCOUNTING_FIRM_COLLECTION;
  }

  run() {
    return new Promise((resolve, reject) => {
      this.mongoRepo.collection(this.invitationsCollection)
        .then(collection => {
          collection.find({}, (error, invitations) => {
            if (error) { // No invitations found
              return resolve(204);
            }
            const foundInvitations = [];
            return invitations.each((invitationsErr, item) => {
              if (item) {
                const dueDate = new Date(item.invitation.dueDateTime);
                const now = new Date();

                if (item.invitation.invitationStatusCode.codeValue === 'open' && dueDate < now) {
                  item.invitation.invitationStatusCode.codeValue = 'expired'; // eslint-disable-line no-param-reassign
                  foundInvitations.push(item);
                  collection.save(item, (err) => {
                    if (err) {
                      this.logger.error(`file="ExpireClientInvitationsAction" msg="Mongo collection update error" invitationID="${item._id}" error=${(err || {}).message}`);
                      return reject(500);
                    }
                    this.logger.info(`file="ExpireClientInvitationsAction" msg="invitation expired" invitationID="${item._id}"`);

                    return true;
                  });
                }
              }
              // The cursor is exhausted/empty and closed
              if (item === null) {
                return resolve(foundInvitations.length);
              }
              return true;
            });
          });
        })
      .catch((error) => {
        this.logger.error(`file="ExpireClientInvitationsAction" msg="Mongo collection error" error=${(error || {}).message}`);
        return reject(500);
      });
    });
  }
};


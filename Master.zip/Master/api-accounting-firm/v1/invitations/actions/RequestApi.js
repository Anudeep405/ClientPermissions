'use strict';

const request = require('request');
const _ = require('lodash');

module.exports = class RequestApi {
  constructor(logger, req) {
    this.logger = logger;
    this.req = req;
  }

  run(url, method, headers, body) {
    return new Promise((resolve, reject) => {
      const reqParams = {};
      reqParams.url = url;
      reqParams.json = true;
      reqParams.method = method || 'GET';
      reqParams.body = body || undefined;
      reqParams.headers = headers || {};
      reqParams.headers['adpx-transactionid'] = headers['adpx-transactionid'] || _.get(this.req, 'headers["adpx-transactionid"]') || '';
      reqParams.headers['adp-messageid'] = headers['adp-messageid'] || _.get(this.req, 'headers["adp-messageid"]') || '';
      reqParams.headers['adp-correlationid'] = headers['adp-correlationid'] || _.get(this.req, 'headers["adp-correlationid"]') || '';
      reqParams.headers['cache-control'] = headers['cache-control'] || _.get(this.req, 'headers["cache-control"]') || '';

      request(reqParams, (error, response, result) => {
        const statusCode = _.get(response, 'statusCode');

        if (error || statusCode !== 200) {
          this.logger.error(`file="RequestApiAction" msg="Cannot get record for API" url="${reqParams.url}" statusCode=${statusCode} error="${_.get(error, 'message')}"`);
          if (statusCode === 500) {
            return reject(500);
          }
          return reject(error);
        }
        if (typeof result === 'object') {
          return resolve(result);
        }

        this.logger.error(`file="RequestApiAction" msg="invalid response object" url="${reqParams.url}" statusCode=${statusCode} response="${result}"`);
        return reject(400);
      });
    });
  }
};

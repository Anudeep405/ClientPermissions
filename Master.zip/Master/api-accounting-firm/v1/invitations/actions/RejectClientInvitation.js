'use strict';

module.exports = class RejectClientInvitation {
  constructor(deps) {
    this.logger = deps.logger;
    this.mongoRepo = deps.mongoRepo;
    this.collectionName = deps.config.ACCOUNTING_FIRM_COLLECTION;
    this.objectID = deps.mongodb.ObjectID;
  }

  run(params) {
    const now = (new Date()).toISOString();
    const uQuery = {
      _id: this.objectID(params.invitationid),
      'invitation.client.organizationOID': params.organizationOID,
      'invitation.invitationStatusCode.codeValue': 'open',
      'invitation.dueDateTime': {
        $gt: now
      }
    };
    const uSet = { $set: params.set };

    return new Promise((resolve, reject) => {
      this.mongoRepo.collection(this.collectionName)
        .then(collection => {
          collection.update(uQuery, uSet, {}, function (err, resData) {
            if (err) {
              return reject(500);
            }
            if (resData.result && resData.result.nModified) {
              return resolve();
            }
            return reject(404);
          });
        })
        .catch((error) => {
          this.logger.error(`file="RejectClientInvitationAction" msg="Mongo collection error" error="${(error || {}).message}"`);
          return reject(500);
        });
    });
  }
};

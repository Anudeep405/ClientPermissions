'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;

describe('Sample Accounting-Firm Integration Test', function() {
  it('passes', () => {
     expect(true).to.equal.true;
  }); 
});

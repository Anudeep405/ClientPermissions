'use strict';

const expect = require('chai').expect;
const util = require('util');
const request = require('request');
const Config = require('../../config');
const config = new Config();
const accountingFirmDocs = require('@adp-sir/api-accounting-firm-docs').create();
const testIdentities = require('@adp-sir/ngcoreapi-int-test-identities');
const jsonschema = new (require('jsonschema').Validator)();
const copy = function(obj) {
  return JSON.parse(JSON.stringify(obj));
}


describe('Accounting Firm API: Get Invitations tests @ ' + config.INVITATIONS_LIST_API_URL, () => {

  // let reportingRequestSample;
  let invitationsResponseSchema;
  let accountant1Client2;
  let accountant1Client1;

  before((done) => {
      testIdentities.create('invitations', 'v1').then((identities) => {
        console.log(identities);

        accountant1Client1 = {
          accountantOOID: identities[0].organizationOID,
          accountantAOID: identities[0].associateOID,
          clientOOID: identities[0].clients[0].organizationOID,
          clientAOID: identities[0].clients[0].associateOID,
          clientIID: identities[0].clients[0].iid
        }
        accountant1Client2 = {
          accountantOOID: identities[0].organizationOID,
          accountantAOID: identities[0].associateOID,
          clientOOID: identities[0].clients[1].organizationOID,
          clientAOID: identities[0].clients[1].associateOID,
          clientIID: identities[0].clients[1].iid
        }

        accountingFirmDocs.getRequestSample(config.INVITATIONS_LIST_API_PATH, (error, result) => {
          // reportingRequestSample = result;
          accountingFirmDocs.getResponseSchema('accounting-firm/v1/client-access-invitations', (error, result) => {
            invitationsResponseSchema = result;
            done();
          });
        })
      });
  });

  describe('Makes successful request', () => {

    let response;

    before((done) => {
      const requestOptions = {
        uri: config.INVITATIONS_LIST_API_URL,
        headers: {
          orgoid: accountant1Client1.accountantOOID,
          associateoid: accountant1Client1.accountantAOID,
          'content-type': 'application/json',
          'cache-control': 'no-cache'
        },
        json: true
      };
      request.get(requestOptions, (err, resp, bod) => {
        response = resp;
        done();
      });
    });

    it('status code is 200', () => {
      expect(response.statusCode).to.equal(200);
    });
    
    /*it('matches schema', () => {
      let validation = jsonschema.validate(response.body, invitationsResponseSchema);
      expect(validation.valid, validation).to.be.true;
    });*/
    
    // TODO: test schema

    it ('invitations are sorted correctly', () => {

      function compare(invitation1, invitation2) {
        if (invitation1.invitationID < invitation2.invitationID) {
          return 1;
        }
        if (invitation1.invitationID > invitation2.invitationID) {
          return -1;
        }
        return 0;
      }

      const sortedResponse = copy(response.body.invitations).sort(compare);
      expect(JSON.stringify(sortedResponse)).to.equal(JSON.stringify(response.body.invitations));

    });

  });


  describe('Makes unsuccessful request by invitation id', () => {

    let response;
    const badInvitationID = '111111111';

    before((done) => {
      const requestOptions = {
        uri: config.INVITATION_BY_INVITATIONID_URL.replace(':invitationid', badInvitationID),
        headers: {
          orgoid: accountant1Client1.accountantOOID,
          associateoid: accountant1Client1.accountantAOID,
          'content-type': 'application/json',
          'cache-control': 'no-cache'
        },
        params: {
          invitationid: badInvitationID
        },        
        json: true
      };
      request.get(requestOptions, (err, resp, bod) => {
        response = resp;
        done();
      });
    });

    it('status code is 204', () => {
      expect(response.statusCode).to.equal(204);
    });
    /*
     it('matches schema', () => {
     let validation = jsonschema.validate(response.body, invitationsResponseSchema);
     expect(validation.valid, validation).to.be.true;
     });
     */
    // TODO: test schema

  });

  describe('Handles invalid headers', () => {

    let response;

    before((done) => {
      const requestOptions = {
        uri: config.INVITATIONS_LIST_API_URL,
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache'
        },
        json: true
      };
      request.get(requestOptions, (err, resp, bod) => {
        response = resp;
        done();
      });
    });

    it('status code is 400', () => {
      expect(response.statusCode).to.equal(400);
    });

    it('has no body', () => {
      expect(response.body).to.be.empty;
    });

  });

});

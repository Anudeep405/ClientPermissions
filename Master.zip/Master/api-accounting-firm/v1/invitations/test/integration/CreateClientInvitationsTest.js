'use strict';

const expect = require('chai').expect;
const util = require('util');
const request = require('request');
const config = new(require('../../config'))();
const accountingFirmDocs = require('@adp-sir/api-accounting-firm-docs').create();
const companyDocs = require('@adp-sir/api-company-docs').create();
const jsonschema = new(require('jsonschema').Validator)();
const clone = function(obj) {
	return JSON.parse(JSON.stringify(obj));
};

const testIdentities = require('@adp-sir/ngcoreapi-int-test-identities');


describe('Accounting Firm API: Create Invitations tests @ ' + config.INVITATION_CREATE_API_PATH, () => {

	let createInvitationRequestSample;
	let createInvitationResponseSchema;
	let createInvitationResponseSchema400;
	let addAccountantRequestSample;
	
	let accountant1Client2;
	let accountant1Client1;
	let multipleOrgoidMatches;


	before((done) => {
		accountingFirmDocs.getRequestSample(config.INVITATION_CREATE_API_PATH)
			.then((result) => {
				createInvitationRequestSample = result;
				return accountingFirmDocs.getResponseSchema(config.INVITATION_CREATE_API_PATH);
			})
			.then((result) => {
				createInvitationResponseSchema = result;
				return accountingFirmDocs.getErrorResponseSchema(config.INVITATION_CREATE_API_PATH, 400);
			})
			.then((result) => {
				createInvitationResponseSchema400 = result;
				return companyDocs.getRequestSample(config.ADD_ACCOUNTANT_API_PATH);
			})
			.then((result) => {
				addAccountantRequestSample = result;

				testIdentities.create('invitations', 'v1').then((identities) => {
					console.log(identities);

					accountant1Client1 = {
						accountantOOID: identities[0].organizationOID,
						accountantAOID: identities[0].associateOID,
						clientOOID: identities[0].clients[0].organizationOID,
						clientAOID: identities[0].clients[0].associateOID,
						clientIID: identities[0].clients[0].iid
					};
					accountant1Client2 = {
						accountantOOID: identities[0].organizationOID,
						accountantAOID: identities[0].associateOID,
						clientOOID: identities[0].clients[1].organizationOID,
						clientAOID: identities[0].clients[1].associateOID,
						clientIID: identities[0].clients[1].iid
					};
					multipleOrgoidMatches = identities[0].clients[2].fein;
					done();
				});

			})
			.catch((error) => {
				done(error);
			})
	});

	describe('Makes a successful request (some fein that does not exist)', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let getResponseBody;

		before((done) => {

			const requestSample = clone(createInvitationRequestSample);
			requestSample.events[0].actor.organizationOID = accountant1Client1.accountantOOID;
			requestSample.events[0].actor.associateOID = accountant1Client1.accountantAOID;
			requestSample.events[0].data.eventContext.client.iid = undefined;
			requestSample.events[0].data.eventContext.client.fein = "123123123";
			const requestOptions = {
				uri: config.INVITATION_CREATE_API_URL,
				json: true,
				body: requestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: accountant1Client1.accountantOOID,
					associateOID: accountant1Client1.accountantAOID,
				}
			};
			request.post(requestOptions, (error, response, body) => {
				responseError = error;
				responseBody = body;
				statusCode = (response || {}).statusCode;
				let invitationID = body.events[0].data.output.invitation.invitationID;
				const requestOptions = {
					uri: config.INVITATION_BY_INVITATIONID_URL.replace(':invitationid', invitationID),
					json: true,
					headers: {
						orgOID: accountant1Client1.accountantOOID,
						associateOID: accountant1Client1.accountantAOID,
					}
				};
				request.get(requestOptions, (error, response, body) => {
					getResponseBody = body;
					done();
				});
			});
		});

		it('request succeeded', () => {
			expect(responseError).to.not.exist;
		});

		it('response status code is 200', () => {
			expect(statusCode).to.equal(200);
		});

		it('the invitation was persisted on the db', () => {
			expect(getResponseBody.invitations.length).to.equal(1);
		});

		it('the response matches the schema', () => {
			const validation = jsonschema.validate(responseBody, createInvitationResponseSchema);
			expect(validation.valid, validation).to.be.true;
		});

	});


	describe('Makes a successful request (some iid that does not exist)', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let getResponseBody;

		before((done) => {
			const requestSample = clone(createInvitationRequestSample);
			requestSample.events[0].actor.organizationOID = accountant1Client1.accountantOOID;
			requestSample.events[0].actor.associateOID = accountant1Client1.accountantAOID;
			requestSample.events[0].data.eventContext.client.fein = undefined;
			requestSample.events[0].data.eventContext.client.iid = "12345678";
			const requestOptions = {
				uri: config.INVITATION_CREATE_API_URL,
				json: true,
				body: requestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: accountant1Client1.accountantOOID,
					associateOID: accountant1Client1.accountantAOID,
				}
			};
			request.post(requestOptions, (error, response, body) => {
				responseError = error;
				responseBody = body;
				statusCode = (response || {}).statusCode;
				let invitationID = body.events[0].data.output.invitation.invitationID;
				const requestOptions = {
					uri: config.INVITATION_BY_INVITATIONID_URL.replace(':invitationid', invitationID),
					json: true,
					headers: {
						orgOID: accountant1Client1.accountantOOID,
						associateOID: accountant1Client1.accountantAOID,
					}
				};
				request.get(requestOptions, (error, response, body) => {
					getResponseBody = body;
					done();
				});
			});
		});

		it('request succeeded', () => {
			expect(responseError).to.not.exist;
		});

		it('response status code is 200', () => {
			expect(statusCode).to.equal(200);
		});

		it('the invitation was persisted on the db', () => {
			expect(getResponseBody.invitations.length).to.equal(1);
		});

		it('the response matches the schema', () => {
			const validation = jsonschema.validate(responseBody, createInvitationResponseSchema);
			expect(validation.valid, validation).to.be.true;
		});

	});

	describe('Handles a client that is already linked', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let getResponseBody;

		before((done) => {
			addAccountant(accountant1Client1)
			.then((response) => {
				getFreshCopyOfClientList(accountant1Client1)
				.then((response) => {
					const body = response.body;
					const clientIID = body.clients[0].installationID;
					const requestSample = clone(createInvitationRequestSample);
					requestSample.events[0].actor.organizationOID = accountant1Client1.accountantOOID;
					requestSample.events[0].actor.associateOID = accountant1Client1.accountantAOID;
					requestSample.events[0].data.eventContext.client = {
						iid: clientIID.toString()
					};
					const createInvitationOptions = {
						uri: config.INVITATION_CREATE_API_URL,
						json: true,
						body: requestSample,
						headers: {
							'content-type': 'application/json',
							orgOID: accountant1Client1.accountantOOID,
							associateOID: accountant1Client1.accountantAOID,
						}
					};
					request.post(createInvitationOptions, (error, response, body) => {
						responseError = error;
						responseBody = body;
						statusCode = (response || {}).statusCode;
						done();
					});
				});
			});
		});

		it('request succeeded', () => {
			expect(responseError).to.not.exist;
		});

		it('response status code is 400', () => {
			expect(statusCode).to.equal(400);
		});

		it('response matches schema', () => {
			const validation = jsonschema.validate(responseBody, createInvitationResponseSchema400);
			expect(validation.valid, validation).to.be.true;
		});

		it('response informs it\'s already a client', () => {
			expect(responseBody.confirmMessage.resourceMessages[0].processMessages[0].messageTypeCode.shortName).to.equal('already-a-client');
		});

	});


	
	describe('Handles multiple orgoid matches for search field', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let getResponseBody;

		before((done) => {
			const requestSample = clone(createInvitationRequestSample);
			requestSample.events[0].actor.organizationOID = accountant1Client1.accountantOOID;
			requestSample.events[0].actor.associateOID = accountant1Client1.accountantAOID;
			requestSample.events[0].data.eventContext.client = {fein: multipleOrgoidMatches }
			const createInvitationOptions = {
				uri: config.INVITATION_CREATE_API_URL,
				json: true,
				body: requestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: accountant1Client1.accountantOOID,
					associateOID: accountant1Client1.accountantAOID,
				}
			};
			request.post(createInvitationOptions, (error, response, body) => {
				responseError = error;
				responseBody = body;
				statusCode = (response || {}).statusCode;
				done();
			});
		});

		it ('request succeeded', () => {
			expect(responseError).to.not.exist;
		});

		it ('response status code is 422', () => {
			expect(statusCode).to.equal(422);
		});

		it ('response matches schema', () => {
			const validation = jsonschema.validate(responseBody, createInvitationResponseSchema400);
			expect(validation.valid, validation).to.be.true;
		});

		it ('response informs there are multiple matches', () => {
			expect(responseBody.confirmMessage.resourceMessages[0].processMessages[0].messageTypeCode.shortName).to.equal('multi-company-match');
		});

	});



	describe('Handles an invalid request body', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let getResponseBody;

		before((done) => {
			const requestSample = clone(createInvitationRequestSample);
			requestSample.events[0].actor.organizationOID = accountant1Client1.accountantOOID;
			requestSample.events[0].actor.associateOID = accountant1Client1.accountantAOID;
			requestSample.events[0].data.eventContext.client = {
				fein: '123123',
				iid: '123123'
			};
			const createInvitationOptions = {
				uri: config.INVITATION_CREATE_API_URL,
				json: true,
				body: requestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: accountant1Client1.accountantOOID,
					associateOID: accountant1Client1.accountantAOID,
				}
			};
			request.post(createInvitationOptions, (error, response, body) => {
				responseError = error;
				responseBody = body;
				statusCode = (response || {}).statusCode;
				done();
			});
		});

		it('request succeeded', () => {
			expect(responseError).to.not.exist;
		});

		it('response status code is 400', () => {
			expect(statusCode).to.equal(400);
		});

	});


	function addAccountant(userIdentity) {
		console.log('adding Accountant...');
		return new Promise((resolve, reject) => {
			const addRequestSample = clone(addAccountantRequestSample);
			addRequestSample.events[0].actor.organizationOID = userIdentity.clientOOID;
			addRequestSample.events[0].actor.associateOID = userIdentity.clientAOID;
			addRequestSample.events[0].data.eventContext.firm.organizationOID = userIdentity.accountantOOID;
			addRequestSample.events[0].data.eventContext.client.organizationOID = userIdentity.clientOOID;
			addRequestSample.events[0].data.transform.accessPermissions = {
				"payrollReports": true,
				"payrollApprove": false,
				"generalLedger": true,
				"taxFormsView": true
			};

			const addRequestOptions = {
				uri: config.ADD_ACCOUNTANT_API_URL,
				json: true,
				body: addRequestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: userIdentity.clientOOID,
					associateOID: userIdentity.clientAOID,
				}
			};

			request.post(addRequestOptions, (error, response, body) => {
				if (error || response.statusCode != 200) {
					console.log('Could not add accountant');
					console.log(JSON.stringify(body));
				}
				return resolve({error, response, body})
			});
		});
	}

	function getFreshCopyOfClientList(userIdentity) {
		return new Promise((resolve, reject) => {
			const getClientsOptions = {
				uri: config.GET_CLIENTS_API_URL,
				headers: {
					orgOID: accountant1Client1.accountantOOID,
					associateOID: accountant1Client1.accountantAOID,
					'cache-control': 'no-cache'
				},
				json: true
			};
			request.get(getClientsOptions, (error, response, body) => {
				if (error || response.statusCode != 200) {
					console.log('Could not load client list');
					console.log(JSON.stringify(body));
				}
				return resolve({error, response, body})

			});
		});
	}
});
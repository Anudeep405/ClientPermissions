'use strict';

const expect = require('chai').expect;
const util = require('util');
const request = require('request');
const identities = require('./identities');
const config = new (require('../../config'))();
const accountingFirmDocs = require('@adp-sir/api-accounting-firm-docs').create();
const companyDocs = require('@adp-sir/api-company-docs').create();
const jsonschema = new (require('jsonschema').Validator)();
const clone = function(obj) {
	return JSON.parse(JSON.stringify(obj));
}

const testIdentities = require('@adp-sir/ngcoreapi-int-test-identities');

describe('Accounting Firm API: Accept Invitations tests @ ' + config.INVITATION_ACCEPT_API_PATH, () => {


	let acceptInvitationRequestSample;
	let acceptInvitationResponseSchema;
	let createInvitationRequestSample;
	let removeAccountantRequestSample;
	
	let accountant1Client2;
	let accountant1Client1;

	// make up a tos code and version. It's time based so we know this will be the 'latest'
	const INVITATION_TOS_CODE = 'INTEGRATION_TEST_TOS_CODE' + (new Date()).getTime();
	const INVITATION_TOS_VERSION = '0.0.'+(new Date()).getTime();
	
	before((done) => {
		testIdentities.create('invitations', 'v1').then((identities) => {
			console.log(identities);

			accountant1Client1 = {
			    accountantOOID: identities[0].organizationOID,
			    accountantAOID: identities[0].associateOID,
			    clientOOID: identities[0].clients[0].organizationOID,
			    clientAOID: identities[0].clients[0].associateOID,
			    clientIID: identities[0].clients[0].iid
			}
			accountant1Client2 = {
			    accountantOOID: identities[0].organizationOID,
			    accountantAOID: identities[0].associateOID,
			    clientOOID: identities[0].clients[1].organizationOID,
			    clientAOID: identities[0].clients[1].associateOID,
			    clientIID: identities[0].clients[1].iid
			}

			accountingFirmDocs.getRequestSample(config.INVITATION_ACCEPT_API_PATH)
				.then((result) => {
					console.log(result);
					acceptInvitationRequestSample = result;
					return accountingFirmDocs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH);
				})
				.then((result) => {
					acceptInvitationResponseSchema = result;
					return accountingFirmDocs.getRequestSample(config.INVITATION_CREATE_API_PATH);
				})
				.then((result) => {
					createInvitationRequestSample = result;
					return companyDocs.getRequestSample(config.ADD_ACCOUNTANT_API_PATH);
				})
				.then((result) => {
					removeAccountantRequestSample = result;
					done();
				})
				.catch((error) => {
					done(error);
				})
		});
	});

	describe('Accepts an invitation', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let clientResponseBody;
		let invitationsListResponseBody;
		let getTosAcceptedResponseBody;
		let invitationID;

		before((done) => {

			removeAccountant(accountant1Client2)
				.then((response) => {
					const requestedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": true,
						"taxFormsView": true
					};
					return createInvitation(accountant1Client2, requestedAccessPermissions)
				})
				.then((response) => {
					invitationID = response.body.events[0].data.output.invitation.invitationID;
					const grantedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": false,
						"taxFormsView": true
					};
					return acceptInvitation(accountant1Client2, invitationID, grantedAccessPermissions);
				})
				.then((response) => {
					responseError = response.error;
					responseBody = response.body;
					statusCode = (response.response || {}).statusCode;
					console.log(statusCode);
					return getFreshCopyOfClientList(accountant1Client2);
				})
				.then((response) => {
					clientResponseBody = response.body;
					return getInvitationsList(accountant1Client2);
				})
				.then((response) => {
					invitationsListResponseBody = response.body;
					return getTosAccepted(accountant1Client2);
				})
				.then((response) => {
					getTosAcceptedResponseBody = response.body;
					done();
				})
		});

		it ('response code is 200', () => {
			expect(statusCode).to.equal(200);
		});

		it ('response matches schema', () => {
			const validation = jsonschema.validate(responseBody, acceptInvitationResponseSchema);
			expect(validation.valid, validation).to.be.true;
		});

		
		it ('the client is linked', () => {
			let found = false;
			for (let client of clientResponseBody.clients) {
				if (client.organizationOID === accountant1Client2.clientOOID) {
					found = true;
					break;
				}
			}
			expect(found, 'client not linked').to.be.true;
		});
		
		it ('the invitation is marked as "accepted"', () => {
			let found = false;
			for (let invitation of invitationsListResponseBody.invitations) {
				if (invitationID === invitation.invitationID) {
					expect(invitation.invitationStatusCode.codeValue, invitation.invitationStatusCode.codeValue).to.equal("accepted");
					break;
				}
			}
		});

		it('the client has the correct permissions', () => {
			let found = false;
			for (let client of clientResponseBody.clients) {
				if (client.organizationOID === accountant1Client2.clientOOID) {
					expect(client.accessPermissions.payrollReports).to.equal(true);
					expect(client.accessPermissions.payrollApprove).to.equal(false);
					expect(client.accessPermissions.generalLedger).to.equal(false);
					expect(client.accessPermissions.taxFormsView).to.equal(true);
				}
			}
		});

		it('the client has accepted the TOS', () => {
			let found = false;
			for (let tos of getTosAcceptedResponseBody.tos) {
				if (INVITATION_TOS_CODE === tos.tosCode.codeValue &&
					INVITATION_TOS_VERSION === tos.versionCode.codeValue) {
					found = true;
				}
			}
			expect(found).to.be.true;
		});

		it('user cannot accept invitation twice', (done) => {
			const grantedAccessPermissions = {
				"payrollReports": true,
				"payrollApprove": false,
				"generalLedger": false,
				"taxFormsView": true
			};
			acceptInvitation(accountant1Client2, invitationID, grantedAccessPermissions)
				.then((response) => {
					if (response.response.statusCode === 404) {
						done();
					}
					else {
						done(response.response.statusCode);
					}
				});
		});

	});





	describe('Cannot accept invitation if tos.accept api fails', () => {

		let statusCode;
		let responseBody;
		let responseError;
		let clientResponseBody;
		let invitationsListResponseBody;
		let getTosAcceptedResponseBody;
		let invitationID;
		const TOS_CODE_THAT_FAILS = 123;

		before((done) => {

			removeAccountant(accountant1Client2)
				.then((response) => {
					const requestedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": true,
						"taxFormsView": true
					};
					return createInvitation(accountant1Client2, requestedAccessPermissions)
				})
				.then((response) => {
					invitationID = response.body.events[0].data.output.invitation.invitationID;
					const grantedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": false,
						"taxFormsView": true
					};
					return acceptInvitation(accountant1Client2, invitationID, grantedAccessPermissions, TOS_CODE_THAT_FAILS);
				})
				.then((response) => {
					responseError = response.error;
					responseBody = response.body;
					statusCode = (response.response || {}).statusCode;
					return getFreshCopyOfClientList(accountant1Client2);
				})
				.then((response) => {
					clientResponseBody = response.body;
					return getInvitationsList(accountant1Client2);
				})
				.then((response) => {
					invitationsListResponseBody = response.body;
					return getTosAccepted(accountant1Client2);
				})
				.then((response) => {
					getTosAcceptedResponseBody = response.body;
					done();
				});
		});

		it ('response code is 500', () => {
			expect(statusCode).to.equal(500);
		});

		it ('response matches schema', () => {
			console.log(JSON.stringify(responseBody, null, 4));
		});

		it ('the client is not linked', () => {
			let found = false;
			for (let client of clientResponseBody.clients) {
				if (client.organizationOID === accountant1Client2.clientOOID) {
					found = true;
					break;
				}
			}
			expect(found, 'client should not be linked').to.be.false;
		});

		it ('the invitation is marked as "open"', () => {
			let found = false;
			for (let invitation of invitationsListResponseBody.invitations) {
				if (invitationID === invitation.invitationID) {
					expect(invitation.invitationStatusCode.codeValue, invitation.invitationStatusCode.codeValue).to.equal("open");
					break;
				}
			}
		});

	});



	describe('Cannot accept someone else\'s invitation', () => {

		let unauthorizedAcceptStatusCode;
		let responseBody;
		let responseError;
		let getResponseBody;
		let clientResponseBody;
		let invitationID;

		before((done) => {


			removeAccountant(accountant1Client1)
				.then(() => {
					return removeAccountant(accountant1Client2)
				})
				.then(() => {
					const requestedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": true,
						"taxFormsView": true
					};
					/*
					*	create the invitation with an identity (user 1)
					*/
					return createInvitation(accountant1Client1, requestedAccessPermissions);
				})
				.then((response) => {
					invitationID = response.body.events[0].data.output.invitation.invitationID;
					const grantedAccessPermissions = {
						"payrollReports": true,
						"payrollApprove": false,
						"generalLedger": false,
						"taxFormsView": true
					};
					/*
					*	responds the invitation with another (user 2)
					*/
					return acceptInvitation(accountant1Client2, invitationID, grantedAccessPermissions)
				})
				.then((response) => {
					unauthorizedAcceptStatusCode = response.response.statusCode;
					return getFreshCopyOfClientList(accountant1Client2);
				})
				.then((response) => {
					clientResponseBody = response.response.body;
					done();
				})
		});

		it ('response code is 404', () => {
			expect(unauthorizedAcceptStatusCode).to.equal(404);
		});

		it ('the client is not linked', () => {
			let found = false;
			for (let client of clientResponseBody.clients) {
				if (client.organizationOID === accountant1Client2.clientOOID) {
					found = true;
					break;
				}
			}
			expect(found, 'client not linked').to.be.false;
		});

	});


	function removeAccountant(userIdentity) {
		console.log('removing Accountant...');
		return new Promise((resolve, reject) => {
			const removeRequestSample = clone(removeAccountantRequestSample);
			removeRequestSample.events[0].actor.organizationOID = userIdentity.clientOOID;
			removeRequestSample.events[0].actor.associateOID = userIdentity.clientAOID;
			removeRequestSample.events[0].data.eventContext.firm.organizationOID = userIdentity.accountantOOID;
			removeRequestSample.events[0].data.eventContext.client.organizationOID = userIdentity.clientOOID;
			removeRequestSample.events[0].data.transform.accessPermissions = {
				"payrollReports": false,
				"payrollApprove": false,
				"generalLedger": false,
				"taxFormsView": false
			};

			const removeRequestOptions = {
				uri: config.ADD_ACCOUNTANT_API_URL,
				json: true,
				body: removeRequestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: userIdentity.clientOOID,
					associateOID: userIdentity.clientAOID,
				}
			}

			request.post(removeRequestOptions, (error, response, body) => {
				return resolve({error, response, body})
			});
		});
	}

	function createInvitation(userIdentity, permissions) {
		console.log('Creating Invitation...');
		return new Promise((resolve, reject) => {
			const createRequestSample = clone(createInvitationRequestSample);
			createRequestSample.events[0].actor.organizationOID = userIdentity.accountantOOID;
			createRequestSample.events[0].actor.associateOID = userIdentity.accountantAOID;
			createRequestSample.events[0].data.eventContext.firm.organizationOID = userIdentity.accountantOOID;
			createRequestSample.events[0].data.eventContext.client = {iid: userIdentity.clientIID};
			createRequestSample.events[0].data.transform.invitation.accessPermissions = permissions;

			const createRequestOptions = {
				uri: config.INVITATION_CREATE_API_URL,
				json: true,
				body: createRequestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: userIdentity.accountantOOID,
					associateOID: userIdentity.accountantAOID,
				}
			}

			request.post(createRequestOptions, (error, response, body) => {
				if (error || response.statusCode != 200) {
					console.log('Could not create invitation');
					console.log(JSON.stringify(body, null, 4))
				}
				resolve({error, response, body});
			});
		})
	}

	function acceptInvitation(userIdentity, invitationID, permissions, tosCode) {
		console.log('Accepting Invitation...');
		return new Promise((resolve, reject) => {

			const acceptRequestSample = clone(acceptInvitationRequestSample);
			acceptRequestSample.events[0].actor.organizationOID = userIdentity.clientOOID;
			acceptRequestSample.events[0].actor.associateOID = userIdentity.clientAOID;
			acceptRequestSample.events[0].data.eventContext.invitation.invitationID = invitationID;
			acceptRequestSample.events[0].data.transform.invitation.grantedAccessPermissions = permissions;
			acceptRequestSample.events[0].data.transform.invitation.tos.tosCode.codeValue = tosCode || INVITATION_TOS_CODE;
			acceptRequestSample.events[0].data.transform.invitation.tos.versionCode.codeValue = INVITATION_TOS_VERSION;
			
			const acceptRequestOptions = {
				uri: config.INVITATION_ACCEPT_API_URL,
				json: true,
				body: acceptRequestSample,
				headers: {
					'content-type': 'application/json',
					orgOID: userIdentity.clientOOID,
					associateOID: userIdentity.clientAOID,
				}
			};
			request.post(acceptRequestOptions, (error, response, body) => {
				if (error || response.statusCode != 200) {
					console.log('Could not accept invitation');
					console.log(JSON.stringify(acceptRequestOptions, null, 4))
				}
				else {
					console.log('accepted!');
				}
				return resolve({error, response, body});
			});
		});
	}

	function getFreshCopyOfClientList(userIdentity) {
		console.log('Get Client List...');
		return new Promise((resolve, reject) => {
			const clientRequestOptions = {
				uri: config.GET_CLIENTS_API_URL,
				json: true,
				headers: {
					'content-type': 'application/json',
					'cache-control': 'no-cache',
					orgOID: userIdentity.accountantOOID,
					associateOID: userIdentity.accountantAOID,
				}
			};

			request.get(clientRequestOptions, (error, response, body) => {
				console.log('cache X-Cache-Status: '+response.headers['X-Cache-Status']);
				return resolve({error, response, body})
			});
		})
	};

	function getInvitationsList(userIdentity) {
		console.log('Get Invitations List...');
		return new Promise((resolve, reject) => {
			const invitationsListOptions = {
				uri: config.INVITATIONS_LIST_API_URL,
				json: true,
				headers: {
					orgOID: userIdentity.accountantOOID,
					associateOID: userIdentity.accountantAOID,
				}
			};
			request.get(invitationsListOptions, (error, response, body) => {
				return resolve({error, response, body})
			});
		});
	};

	function getTosAccepted(userIdentity) {
		console.log('Get TOS accepted List...');
		return new Promise((resolve, reject) => {
			const tosAcceptedOptions = {
				uri: config.GET_TOS_ACCEPTED_URL
					.replace(':orgoid', userIdentity.clientOOID)
					.replace(':aoid', userIdentity.clientAOID),
				json: true,
				headers: {
					orgOID: userIdentity.clientOOID,
					associateOID: userIdentity.clientAOID
				}
			};
			request.get(tosAcceptedOptions, (error, response, body) => {
				return resolve({error, response, body})
			});
		});
	};

});




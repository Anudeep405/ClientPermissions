module.exports = {
  accountant1Client1: {
    accountantOOID: 'G39Z5TP4N44H59VT',
    accountantAOID: 'G39Z5TP4N44HV7EW',
    clientOOID: 'G32FYQ2RE093A7NB',
    clientAOID: 'G32FYQ2RE093TSF9',
    clientIID: '89826325'
  },
  accountant1Client2: {
    accountantOOID: 'G39Z5TP4N44H59VT',
    accountantAOID: 'G39Z5TP4N44HV7EW',
    clientOOID: 'G3W5TJX46KDZYERG',
    clientAOID: 'G3W5TJX46KDZ168A',
    clientIID: '89826235'
  },
  feinWithMultipleMatches: '33-7777778',
  clientThatForcesRUNExceptionIID: '89796989',
  clientNotAttachedToAnyAccountants: '89820657'
};


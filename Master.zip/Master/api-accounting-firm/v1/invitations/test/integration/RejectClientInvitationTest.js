'use strict';

const expect = require('chai').expect;
const request = require('request');
const identities = require('./identities');
const config = new (require('../../config'))();
const accountingFirmDocs = require('@adp-sir/api-accounting-firm-docs').create();
const companyDocs = require('@adp-sir/api-company-docs').create();
const jsonschema = new (require('jsonschema').Validator)();
const clone = function(obj) {
  return JSON.parse(JSON.stringify(obj));
}

const testIdentities = require('@adp-sir/ngcoreapi-int-test-identities');

describe('Accounting Firm API: Reject Invitations tests @ ' + config.INVITATION_REJECT_API_PATH, () => {


  let rejectInvitationRequestSample;
  let rejectInvitationResponseSchema;
  let createInvitationRequestSample;
  let removeAccountantRequestSample;

  let accountant1Client2;
  let accountant1Client1;

  before((done) => {
    testIdentities.create('invitations', 'v1').then((identities) => {
      console.log(identities);

      accountant1Client1 = {
        accountantOOID: identities[0].organizationOID,
        accountantAOID: identities[0].associateOID,
        clientOOID: identities[0].clients[0].organizationOID,
        clientAOID: identities[0].clients[0].associateOID,
        clientIID: identities[0].clients[0].iid
      }
      accountant1Client2 = {
        accountantOOID: identities[0].organizationOID,
        accountantAOID: identities[0].associateOID,
        clientOOID: identities[0].clients[1].organizationOID,
        clientAOID: identities[0].clients[1].associateOID,
        clientIID: identities[0].clients[1].iid
      }

      accountingFirmDocs.getRequestSample(config.INVITATION_REJECT_API_PATH)
        .then((result) => {
          rejectInvitationRequestSample = result;
          return accountingFirmDocs.getResponseSchema(config.INVITATION_REJECT_API_PATH);
        })
        .then((result) => {
          rejectInvitationResponseSchema = result;
          return accountingFirmDocs.getRequestSample(config.INVITATION_CREATE_API_PATH);
        })
        .then((result) => {
          createInvitationRequestSample = result;
          return companyDocs.getRequestSample(config.ADD_ACCOUNTANT_API_PATH);
        })
        .then((result) => {
          removeAccountantRequestSample = result;
          done();
        })
        .catch((error) => {
          done(error);
        })
    });
  });

  describe('Reject an invitation', () => {

    let statusCode;
    let responseBody;
    let responseError;
    let clientResponseBody;
    let invitationsListResponseBody;
    let invitationID;

    before((done) => {

      removeAccountant(accountant1Client2)
        .then((response) => {
          const requestedAccessPermissions = {
            "payrollReports": true,
            "payrollApprove": false,
            "generalLedger": true,
            "taxFormsView": true
          };
          return createInvitation(accountant1Client2, requestedAccessPermissions)
        })
        .then((response) => {
          invitationID = response.body.events[0].data.output.invitation.invitationID;
          return rejectInvitation(accountant1Client2, invitationID);
        })
        .then((response) => {
          responseError = response.error;
          responseBody = response.body;
          statusCode = (response.response || {}).statusCode;
          return getFreshCopyOfClientList(accountant1Client2);
        })
        .then((response) => {
          clientResponseBody = response.body;
          return getInvitationsList(accountant1Client2);
        })
        .then((response) => {
          invitationsListResponseBody = response.body;
          done();
        })
    });

    it ('response code is 200', () => {
      expect(statusCode).to.equal(200);
    });

    it ('response matches schema', () => {
      const validation = jsonschema.validate(responseBody, rejectInvitationResponseSchema);
      expect(validation.valid, validation).to.be.true;
    });

    it ('the invitation is marked as "rejected"', () => {
      for (let invitation of invitationsListResponseBody.invitations) {
        if (invitationID === invitation.invitationID) {
          expect(invitation.invitationStatusCode.codeValue, invitation.invitationStatusCode.codeValue).to.equal("rejected");
          break;
        }
      }
    });

    it('user cannot reject invitation twice', (done) => {
      rejectInvitation(accountant1Client2, invitationID)
        .then((response) => {
          if (response.response.statusCode === 404) {
            done();
          }
          else {
            done(response.response.statusCode);
          }
        });
    });

  });

  function removeAccountant(userIdentity) {
    console.log('removing Accountant...');
    return new Promise((resolve, reject) => {
      const removeRequestSample = clone(removeAccountantRequestSample);
      removeRequestSample.events[0].actor.organizationOID = userIdentity.clientOOID;
      removeRequestSample.events[0].actor.associateOID = userIdentity.clientAOID;
      removeRequestSample.events[0].data.eventContext.firm.organizationOID = userIdentity.accountantOOID;
      removeRequestSample.events[0].data.eventContext.client.organizationOID = userIdentity.clientOOID;
      removeRequestSample.events[0].data.transform.accessPermissions = {
        "payrollReports": false,
        "payrollApprove": false,
        "generalLedger": false,
        "taxFormsView": false
      };

      const removeRequestOptions = {
        uri: config.ADD_ACCOUNTANT_API_URL,
        json: true,
        body: removeRequestSample,
        headers: {
          'content-type': 'application/json',
          orgOID: userIdentity.clientOOID,
          associateOID: userIdentity.clientAOID,
        }
      }

      request.post(removeRequestOptions, (error, response, body) => {
        return resolve({error, response, body})
      });
    });
  }

  function createInvitation(userIdentity, permissions) {
    console.log('Creating Invitation...');
    return new Promise((resolve, reject) => {
      const createRequestSample = clone(createInvitationRequestSample);
      createRequestSample.events[0].actor.organizationOID = userIdentity.accountantOOID;
      createRequestSample.events[0].actor.associateOID = userIdentity.accountantAOID;
      createRequestSample.events[0].data.eventContext.firm.organizationOID = userIdentity.accountantOOID;
      createRequestSample.events[0].data.eventContext.client = {iid: userIdentity.clientIID};
      createRequestSample.events[0].data.transform.invitation.accessPermissions = permissions;

      const createRequestOptions = {
        uri: config.INVITATION_CREATE_API_URL,
        json: true,
        body: createRequestSample,
        headers: {
          'content-type': 'application/json',
          orgOID: userIdentity.accountantOOID,
          associateOID: userIdentity.accountantAOID,
        }
      }

      request.post(createRequestOptions, (error, response, body) => {
        if (error || response.statusCode != 200) {
          console.log('Could not create invitation');
          console.log(JSON.stringify(body, null, 4))
        }
        resolve({error, response, body});
      });
    })
  }

  function rejectInvitation(userIdentity, invitationID) {
    console.log('Rejecting Invitation...');
    return new Promise((resolve, reject) => {
      const rejectRequestSample = clone(rejectInvitationRequestSample);
      rejectRequestSample.events[0].actor.organizationOID = userIdentity.clientOOID;
      rejectRequestSample.events[0].actor.associateOID = userIdentity.clientAOID;
      rejectRequestSample.events[0].data.eventContext.invitation.invitationID = invitationID;
      const rejectRequestOptions = {
        uri: config.INVITATION_REJECT_API_URL,
        json: true,
        body: rejectRequestSample,
        headers: {
          'content-type': 'application/json',
          orgOID: userIdentity.clientOOID,
          associateOID: userIdentity.clientAOID,
        }
      };
      request.post(rejectRequestOptions, (error, response, body) => {
        if (error || response.statusCode != 200) {
          console.log('Could not reject invitation');
          console.log(JSON.stringify(rejectRequestOptions, null, 4))
        }
        else {
          console.log('rejected!');
        }
        return resolve({error, response, body});
      });
    });
  }

  function getFreshCopyOfClientList(userIdentity) {
    console.log('Get Client List...');
    return new Promise((resolve, reject) => {
      const clientRequestOptions = {
        uri: config.GET_CLIENTS_API_URL,
        json: true,
        headers: {
          'content-type': 'application/json',
          'cache-control': 'no-cache',
          orgOID: userIdentity.accountantOOID,
          associateOID: userIdentity.accountantAOID,
        }
      };

      request.get(clientRequestOptions, (error, response, body) => {
        console.log('cache X-Cache-Status: '+response.headers['X-Cache-Status']);
        return resolve({error, response, body})
      });
    })
  };

  function getInvitationsList(userIdentity) {
    console.log('Get Invitations List...');
    return new Promise((resolve, reject) => {
      const invitationsListOptions = {
        uri: config.INVITATIONS_LIST_API_URL,
        json: true,
        headers: {
          orgOID: userIdentity.accountantOOID,
          associateOID: userIdentity.accountantAOID,
        }
      };
      request.get(invitationsListOptions, (error, response, body) => {
        return resolve({error, response, body})
      });
    });
  };

});
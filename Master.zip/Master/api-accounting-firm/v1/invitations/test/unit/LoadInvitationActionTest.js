'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();

const LoadInvitation = require('../../actions/LoadInvitation');
const Config = require('../../config');
const config = new Config();

describe('Load Invitation Action Unit Test - ', function() {
  const sandbox = sinon.sandbox.create();
  let deps;

  const resolvePromise = function(output) {
    return new Promise((resolve, reject) => {
      resolve(output);
    });
  };

  const rejectPromise = function(output) {
    return new Promise((resolve, reject) => {
      reject(output);
    });
  };

  function init() {
    deps = {
      logger: {
        error: sandbox.stub(),
        info: sandbox.stub()
      },
      mongoRepo: {
        collection: sandbox.stub()
      },
      mongodb: {
        ObjectID: sandbox.stub()
      },
      config: config
    };
  }

  afterEach(() => {
    sandbox.restore();
  });

  describe(' failed to load invitation ', function(done) {
    let responseBody;
    let responseStatusCode;
    const invitationid = '57a22fdb0235e1f800543aa9';
    const organizationOID = '2222';

    before((done) => {
      init();
      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          const mObject = {
            find: function (body, option) {
              return {
                toArray: function (callback) {
                  callback({ message: 'Error to load Invitation' }, [{ test: 'test' }]);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      let loadInvitation = new LoadInvitation(deps);
      loadInvitation.run(invitationid, organizationOID)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe(' invitation not found ', function(done) {
    let responseBody;
    let responseStatusCode;
    const invitationid = '57a22fdb0235e1f800543aa9';
    const organizationOID = '2222';

    before((done) => {
      init();
      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          const mObject = {
            find: function (body, option) {
              return {
                toArray: function (callback) {
                  callback(null, []);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      let loadInvitation = new LoadInvitation(deps);
      loadInvitation.run(invitationid, organizationOID)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 404', () => {
      expect(responseStatusCode).to.equal(404);
    });
  });

  describe(' failed to load invitation because of DB error', function(done) {
    let responseBody;
    let responseStatusCode;
    const invitationid = '57a22fdb0235e1f800543aa9';
    const organizationOID = '2222';

    before((done) => {
      init();
      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          reject({ message: 'MongoDB Error' });
        })
      );
      let loadInvitation = new LoadInvitation(deps);
      loadInvitation.run(invitationid, organizationOID)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe(' a valid invitation request', function(done) {
    let responseBody;
    let responseStatusCode;
    const invitationid = '57a22fdb0235e1f800543aa9';
    const organizationOID = '2222';

    before((done) => {
      init();
      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          const mObject = {
            find: function (body, option) {
              return {
                toArray: function (callback) {
                  callback(null, [{ test: 'test' }]);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      let loadInvitation = new LoadInvitation(deps);
      loadInvitation.run(invitationid, organizationOID)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 200', () => {
      expect(responseStatusCode).to.equal(200);
    });

    it ('response body is valid', () => {
      expect(responseBody).to.exist;
      expect(responseBody.test).to.equal('test');
    });

  });
});

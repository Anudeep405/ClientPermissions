'use strict';

const util = require('util');
const request = require('request');
const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();
const docs = require('@adp-sir/api-accounting-firm-docs').create();
const AcceptClientHandler = require('../../handlers/AcceptClientInvitation');
const Config = require('../../config');
const config = new Config();
const identities = require('../integration/identities');
const invitationData = {
  _id : '57bdc6360141fa01008eb7cc',
  actor : {
    formattedName : 'John Smith',
    associateOID : 'G3E1YK2CJPWBY6JN',
    organizationOID : 'G3E1YK2CJPWBE19B',
    applicationID : {
      idValue : 'JUDNDBDH6666'
    }
  },
  invitation : {
    creationDateTime : '2016-08-24T16:07:18.239Z',
    dueDateTime : '2016-09-08T16:07:18.239Z',
    invitationLabel : 'Pet Shop Pro',
    invitationMessage : 'Personal message to invitee',
    invitationStatusCode : {
      codeValue : 'open'
    },
    grantedAccessPermissions : {},
    requestedAccessPermissions : {
      payrollReports : true,
      payrollApprove : false,
      generalLedger : true,
      taxFormsView : true
    },
    client : {
      iid : '89821237',
      organizationOID : 'G3CW2HBFH4BF1ZA9'
    },
    firm : {
      organizationOID : 'G3E1YK2CJPWBE19B',
      legalNameAtTimeOfRequest : 'he Firm'
    }
  }
}

describe('AcceptClientInvitations Handler Unit Test - ', function() {

  const sandbox = sinon.sandbox.create();
  const consumerAOID = '123';
  const requestApiInstance = {
    run: sandbox.stub()
  };
  const loadInvitationInstance = {
    run: sandbox.stub()
  };
  const acceptClientInvitationInstance = {
    run: sandbox.stub()
  };
  const loggerStub = {
    error: sandbox.stub(),
    info: sandbox.stub()
  };

  let deps;

  const resolvePromise = function(output) {
    return new Promise((resolve, reject) => {
      resolve(output);
    });
  };

  const rejectPromise = function(output) {
    return new Promise((resolve, reject) => {
      reject(output);
    });
  };

  function init() {
    deps = {
      mongoRepo: {
        collection: sandbox.stub()
      },
      config: config,
      RequestApi: sandbox.stub(),
      LoadInvitation: sandbox.stub(),
      AcceptClientInvitation: sandbox.stub()
    };

    deps.RequestApi.returns(requestApiInstance);
    deps.LoadInvitation.returns(loadInvitationInstance);
    deps.AcceptClientInvitation.returns(acceptClientInvitationInstance);
  }

  describe('400 with missing AOID', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    const getUserContactsResponse = {
      contact: {
        legalName: {
          givenName: 'fname',
          familyName: 'fname'
        },
        communication: {
          emails: [{
            emailUri: 'test@adp.com'
          }]
        }
      }
    };

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise(getUserContactsResponse))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': Error', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('InvitationID is missing', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          resultRequest.events[0].data.eventContext.invitation.invitationID = null;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (' with  error 400', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('Failed to load Invitation data ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(rejectPromise(null));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('with error code : 500', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('Failed to save legal ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(rejectPromise(null))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': Error 500', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('Failed to add in RUN ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(rejectPromise(500))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': Error 500', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('Failed to save in mongodb ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(rejectPromise(null));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': error 500', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('Failed to get contact ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(rejectPromise('test contact missing'))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('but still valid request', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('Failed to send notification ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
            legalName: { givenName: 'fname', familyName: 'fname' },
            communication: { emails: [{ emailUri: 'test@adp.com' }]} }
          }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(rejectPromise('Notification error'))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('but still valid request', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('handles a valid request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_ACCEPT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_ACCEPT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientAOID,
              associateoid: identities.accountant1Client1.clientOOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          loadInvitationInstance.run.returns(resolvePromise(invitationData));
          acceptClientInvitationInstance.run.returns(resolvePromise(true));

          const raPara1 = config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', invitationData.actor.associateOID);
          requestApiInstance.run
            .withArgs(config.ACCEPT_LEGAL_API_URL).returns(resolvePromise(true))
            .withArgs(config.ADD_ACCOUNTANT_API_URL).returns(resolvePromise({ }))
            .withArgs(raPara1).returns(resolvePromise({ contact: {
              legalName: { givenName: 'fname', familyName: 'fname' },
              communication: { emails: [{ emailUri: 'test@adp.com' }]} }
            }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let acceptClientHandler = new AcceptClientHandler(deps);
          let handler = acceptClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });
});

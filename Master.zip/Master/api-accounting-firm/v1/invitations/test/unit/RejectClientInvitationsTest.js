'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();
const docs = require('@adp-sir/api-accounting-firm-docs').create();
const RejectClientHandler = require('../../handlers/RejectClientInvitation');
const RejectClientInvitationAction = require('../../actions/RejectClientInvitation');
const ConfigSetting = require('../../config');
const config = new ConfigSetting();
const identities = require('../integration/identities');

describe('Reject Client Invitations Unit Test - ', function() {

  const sandbox = sinon.sandbox.create();
  const mongoRepo = {
    collection: sandbox.stub()
  };
  const loggerStub = {
    error: sandbox.stub(),
    info: sandbox.stub()
  };
  let deps;

  function init() {
    deps = {
      mongoRepo: mongoRepo,
      mongodb: {
        ObjectID: function (id) {
          return id;
        }
      },
      config: config,
      RejectClientInvitation: RejectClientInvitationAction
    };
  }

  describe('Bad request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: null
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 1 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('with missing OOID: 400', () => {
      expect(statusCode).to.equal(400);
    });
  });
  describe('Bad request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: null,
              associateoid: identities.accountant1Client1.clientAOID,
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 1 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('with missing AOID: 400', () => {
      expect(statusCode).to.equal(400);
    });
  });
  describe('Bad request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          const bodyRequest = resultRequest;
          bodyRequest.events[0].data.eventContext.invitation.invitationID = null;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: identities.accountant1Client1.clientAOID,
            },
            body: bodyRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 1 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('with missing invitationID: 400', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('invitation not found', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: identities.accountant1Client1.clientAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 0 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': 404', () => {
      expect(statusCode).to.equal(404);
    });
  });
  describe('invitation already reject or accepted', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: identities.accountant1Client1.clientAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 0 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': 404', () => {
      expect(statusCode).to.equal(404);
    });
  });
  describe('DB, system or unknown error ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: identities.accountant1Client1.clientAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              reject({ message: 'DB or unknown error' });
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it (': 500', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('handles a valid request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_REJECT_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_REJECT_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.clientOOID,
              associateoid: identities.accountant1Client1.clientAOID
            },
            body: resultRequest,
            logger: loggerStub
          };
          mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
              var mObject = {
                update: function (query, update, option, callback) {
                  callback(null, { result: { nModified: 1 } });
                }
              };
              resolve(mObject);
            })
          );

          let rejectClientHandler = new RejectClientHandler(deps);
          let handler = rejectClientHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });
});

'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();

const AcceptClientInvitation = require('../../actions/AcceptClientInvitation');
const Config = require('../../config');
const config = new Config();

describe('Accept Client Invitation Action Unit Test', function() {
  var sandbox = sinon.sandbox.create();
  var deps;

  function init() {
    deps = {
      logger: {
        error: sandbox.stub(),
        info: sandbox.stub()
      },
      mongoRepo: {
        collection: sandbox.stub()
      },
      mongodb: {
        ObjectID: sandbox.stub()
      },
      config: config
    };
  };

  afterEach(() => {
    sandbox.restore();
  });

  describe('Error in update of old invitation', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '57a22fdb0235e1f800543aa9';

    before((done) => {
      init();

      const params = { invitationid: testId, set: {} };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback({ message: 'Error' }, {});
            }
          };
          resolve(mObject);
        })
      );
      let acceptClientInvitation = new AcceptClientInvitation(deps);
      acceptClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('Error in load the collection', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '57a22fdb0235e1f800543aa9';

    before((done) => {
      init();

      const params = { invitationid: testId, set: {} };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          reject({message:'Collection Error'});
        })
      );
      let acceptClientInvitation = new AcceptClientInvitation(deps);
      acceptClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('Unknown Error', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '57a22fdb0235e1f800543aa9';

    before((done) => {
      init();

      const params = { invitationid: testId, set: {} };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          reject(null);
        })
      );
      let acceptClientInvitation = new AcceptClientInvitation(deps);
      acceptClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('accept invitation a valid request', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '57a22fdb0235e1f800543aa9';

    before((done) => {
      init();

      const params = { invitationid: testId, set: {} };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback(null, { _id: testId });
            }
          };
          resolve(mObject);
        })
      );
      let acceptClientInvitation = new AcceptClientInvitation(deps);
      acceptClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 200', () => {
      expect(responseStatusCode).to.equal(200);
    });

    it ('response body is valid', () => {
      expect(responseBody).to.exist;
      expect(responseBody._id).to.assert(testId);
    });

  });
});

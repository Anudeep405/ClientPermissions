'use strict';

const util = require('util');
const request = require('request');
const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();
const docs = require('@adp-sir/api-accounting-firm-docs').create();
const SendEmailsHandler = require('../../handlers/CreateClientInvitation');
const Config = require('../../config');
const config = new Config();
const identities = require('../integration/identities');

describe('CreateClientInvitations Handler Unit Test', function() {

  const sandbox = sinon.sandbox.create();
  const consumerAOID = '123';
  const invitationID = '11111';

  let deps;
  let requestApiInstance = {
    run: sandbox.stub()
  };
  let storeClientInvitationInstance = {
    run: sandbox.stub()
  };
  let stubLogger = {
    info: sandbox.stub(),
    warn: sandbox.stub(),
    error: sandbox.stub()
  };

  const resolvePromise = function(output) {
    return new Promise((resolve, reject) => {
      resolve(output);
    });
  };

  const rejectPromise = function(output) {
    return new Promise((resolve, reject) => {
      reject(output);
    });
  };

  function init() {
    deps = {
      mongoRepo: {
        collection: sandbox.stub()
      },
      config: config,
      RequestApi: sandbox.stub(),
      StoreClientInvitation: sandbox.stub()
    };
    deps.RequestApi.returns(requestApiInstance);
    deps.StoreClientInvitation.returns(storeClientInvitationInstance);
  }

  describe('handles an invalid request with missing ooid: Error : 400', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    const consumerAOID = '123';

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger,
          };
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('handles an invalid request with missing iid and fein: Error : 400', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          resultRequest.events[0].data.eventContext.client.iid = null;
          resultRequest.events[0].data.eventContext.client.fein = null;
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantAOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('handles a request with an fein that matches multiple companies: Error : 422', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;
    const multipleCompaniesResult = {
      companies: [{
        organizationOID: identities.accountant1Client1.clientOOID
      }, {
        organizationOID: identities.accountant1Client1.clientOOID
      }]
    };
    const firmAddressResponse = {
      contacts: {
        legalAddress: {
          name: 'Test Firm',
          address: {
            countrySubdivisionLevel1: {
              subdivisionType: 'STATE',
              codeValue: 'NJ'
            }
          }
        }
      }
    };

      before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara3 = config.GET_FIRM_SERVICE_REGION_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara4 = config.GET_FIRM_INFO_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);

          requestApiInstance.run
              .withArgs(raPara1).returns(resolvePromise(multipleCompaniesResult))
              .withArgs(raPara2).returns(resolvePromise(firmAddressResponse))
              .withArgs(raPara3).returns(resolvePromise(200))
              .withArgs(raPara4).returns(resolvePromise(200));
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(422);
    });
  });

  describe('handles when orgoid search returns 404: result - 200', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({companies: []}));
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('handles when orgoid search returns no results: result - 200', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          requestApiInstance.run
            .withArgs(raPara1).returns(rejectPromise(404));
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('handles an invalid request but fein is get error: result - 200', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          requestApiInstance.run
            .withArgs(raPara1).returns(rejectPromise(500));
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('handles a request for a client that is already linked to the firm : result - 400', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.clientOOID);
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({ companies: [{ organizationOID: identities.accountant1Client1.clientOOID }] }))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise({ clients: [{organizationOID:identities.accountant1Client1.clientOOID}] }))
            .withArgs(raPara2).returns(resolvePromise({ contacts: { legalAddress: { name: 'Test Firm' } } }))
            .withArgs(raPara3).returns(resolvePromise({
              contacts: [{
                firstName: 'firstName', lastName: 'lastName',
                communication: { emails: [{ emailUri: 'test@adp.com' }] }
              }]
            }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));
          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(res, code) {
              responseBody = res;
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(400);
    });
  });

  describe('handles a valid request with get firm fail : 500 ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.clientOOID);
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({ companies: [{ organizationOID: identities.accountant1Client1.clientOOID }] }))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise({ clients: [] }))
            .withArgs(raPara2).returns(rejectPromise(400))
            .withArgs(raPara3).returns(resolvePromise({
              contacts: [{
                firstName: 'firstName', lastName: 'lastName',
                communication: { emails: [{ emailUri: 'test@adp.com' }] }
              }]
            }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('handles a valid request with store in mongo fail : 500 ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(rejectPromise(400));
          const raPara1 = config.GET_ORGOID_BY_IID_API_URL + 'fein/' + resultRequest.events[0].data.eventContext.client.fein;
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL + identities.accountant1Client1.accountantOOID;
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL + identities.accountant1Client1.clientOOID;
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({ companies: [{ organizationOID: identities.accountant1Client1.clientOOID }] }))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise({ clients: [] }))
            .withArgs(raPara2).returns(resolvePromise({ contacts: { legalAddress: { name: 'Test Firm' } } }))
            .withArgs(raPara3).returns(resolvePromise({
              contacts: [{
                  firstName: 'firstName', lastName: 'lastName',
                  communication: { emails: [{ emailUri: 'test@adp.com' }] },
                  legalAddress: {
                      address: {
                          countrySubdivisionLevel1: {
                              subdivisionType: 'STATE',
                              codeValue: 'NJ'
                          }
                      }
                  }
              }]
            }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('handles a valid request with getting recipient service fail : 500 ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_IID_API_URL + 'fein/' + resultRequest.events[0].data.eventContext.client.fein;
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL + identities.accountant1Client1.accountantOOID;
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL + identities.accountant1Client1.clientOOID;
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({ companies: [{ organizationOID: identities.accountant1Client1.clientOOID }] }))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise({ clients: [] }))
            .withArgs(raPara2).returns(resolvePromise({ contacts: { legalAddress: { name: 'Test Firm' } } }))
            .withArgs(raPara3).returns(rejectPromise(400))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('handles a valid request with notification service fail : 500 ', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_IID_API_URL + 'fein/' + resultRequest.events[0].data.eventContext.client.fein;
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL + identities.accountant1Client1.accountantOOID;
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL + identities.accountant1Client1.clientOOID;
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise({ companies: [{ organizationOID: identities.accountant1Client1.clientOOID }] }))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise({ clients: [] }))
            .withArgs(raPara2).returns(resolvePromise({ contacts: { legalAddress: { name: 'Test Firm' } } }))
            .withArgs(raPara3).returns(resolvePromise({
              contacts: [{
                firstName: 'firstName', lastName: 'lastName',
                communication: { emails: [{ emailUri: 'test@adp.com' }] }
              }]
            }))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(rejectPromise(400))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('handles a valid request but client contacts are empty', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    const noClientsResponse = {
      clients: []
    };
    const searchResultsOneCompany = {
      companies: [{
        organizationOID: identities.accountant1Client1.clientOOID
      }]
    };
    const firmIIDResponse = {
      client: {
        installationID: '12345678'
      }
    };
    const firmAddressResponse = {
      contacts: {
        legalAddress: {
          name: 'Test Firm',
          address: {
            countrySubdivisionLevel1: {
              subdivisionType: 'STATE',
              codeValue: 'NJ'
            }
          }
        }
      }
    };
    const companyContactsResponse = {
      contacts: [{
        firstName: 'firstName',
        lastName: 'lastName',
        communication: {
          emails: [{
            emailUri: 'test@adp.com'
          }]
        }
      }]
    };

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.clientOOID);
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise(searchResultsOneCompany))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise(noClientsResponse))
            .withArgs(raPara2).returns(resolvePromise(firmAddressResponse))
            .withArgs(config.GET_FIRM_INFO_API_URL).returns(resolvePromise(firmIIDResponse))
            .withArgs(raPara3).returns(resolvePromise({ contacts: []}))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });

  describe('handles a valid request', function(done) {
    let responseBody;
    let statusCode;
    let responseSchema;
    let stubRequest;

    const noClientsResponse = {
      clients: []
    };
    const searchResultsOneCompany = {
      companies: [{
        organizationOID: identities.accountant1Client1.clientOOID
      }]
    };
    const firmAddressResponse = {
      contacts: {
        legalAddress: {
          name: 'Test Firm'
        }
      }
    };
    const companyContactsResponse = {
      contacts: [{
        firstName: 'firstName',
        lastName: 'lastName',
        communication: {
          emails: [{
            emailUri: 'test@adp.com'
          }]
        }
      }]
    };

    before((done) => {
      docs.getRequestSample(config.INVITATION_CREATE_API_PATH, (error, resultRequest) => {
        docs.getResponseSchema(config.INVITATION_CREATE_API_PATH, (error, resultResponseSchema) => {
          responseSchema = resultResponseSchema;
          init();
          stubRequest = {
            params: {},
            headers: {
              orgoid: identities.accountant1Client1.accountantOOID,
              associateoid: identities.accountant1Client1.accountantAOID,
              consumeraoid: consumerAOID
            },
            body: resultRequest,
            logger: stubLogger
          };
          storeClientInvitationInstance.run.returns(resolvePromise(invitationID));
          const raPara1 = config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', resultRequest.events[0].data.eventContext.client.fein);
          const raPara2 = config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.accountantOOID);
          const raPara3 = config.GET_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', identities.accountant1Client1.clientOOID);
          requestApiInstance.run
            .withArgs(raPara1).returns(resolvePromise(searchResultsOneCompany))
            .withArgs(config.GET_CLIENTS_API_URL).returns(resolvePromise(noClientsResponse))
            .withArgs(raPara2).returns(resolvePromise(firmAddressResponse))
            .withArgs(raPara3).returns(resolvePromise(companyContactsResponse))
            .withArgs(config.NOTIFICATION_EMAIL_SEND_API_URL).returns(resolvePromise({}))
            .withArgs().returns(resolvePromise({ test: 'test' }));

          let sendEmailsHandler = new SendEmailsHandler(deps);
          let handler = sendEmailsHandler.create();
          handler(stubRequest, {}, {
            completed(response) {
              responseBody = response;
              statusCode = 200;
              done();
            },
            failed(code) {
              statusCode = code;
              done();
            }
          });
        });
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      let validation = jsonschema.validate(responseBody, responseSchema);
      expect(validation.valid, validation).to.be.true;
    });
  });
});

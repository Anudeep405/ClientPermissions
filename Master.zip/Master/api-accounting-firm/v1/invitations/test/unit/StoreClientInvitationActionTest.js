'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();

const StoreClientInvitation = require('../../actions/StoreClientInvitation');
const Config = require('../../config');
const config = new Config();

describe('Store Client Invitation Action Unit Test', function() {
  var sandbox = sinon.sandbox.create();
  var deps;

  function init() {
    deps = {
      logger: {
        error: sandbox.stub(),
        info: sandbox.stub()
      },
      mongoRepo: {
        collection: sandbox.stub()
      },
      config: config
    };
  };

  afterEach(() => {
    sandbox.restore();
  });

  describe('Error in update of old invitation', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '12345';

    before((done) => {
      init();

      const params = { body: {
        actor: {
          organizationOID: 'organizationOID',
          associateOID: 'associateOID'
        },
        invitation: { client: { iid: 'testiid' } }
      } };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          var mObject = {
            insert: function (body, callback) {
              callback(null, {ops: [{ _id: testId }]});
            },
            update: function (query, update, option, callback) {
              callback({ message: 'Error' }, {});
            }
          };
          resolve(mObject);
        })
      );
      let storeClientInvitation = new StoreClientInvitation(deps);
      storeClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('Error in new invitation insert', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '12345';

    before((done) => {
      init();

      const params = { body: {
        actor: {
          organizationOID: 'organizationOID',
          associateOID: 'associateOID'
        },
        invitation: { client: { iid: 'testiid' } }
      } };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          var mObject = {
            insert: function (body, callbackInsert) {
              callbackInsert({ message: 'insert error' }, { ops: [{ _id: testId }] });
            },
            update: function (query, update, option, callback) {
              callback(null, {});
            }
          };
          resolve(mObject);
        })
      );
      let storeClientInvitation = new StoreClientInvitation(deps);
      storeClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('Error in load the collection', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '12345';

    before((done) => {
      init();

      const params = { body: {
        actor: {
          organizationOID: 'organizationOID',
          associateOID: 'associateOID'
        },
        invitation: { client: { iid: 'testiid' } }
      } };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          reject({message:'Collection Error'});
        })
      );
      let storeClientInvitation = new StoreClientInvitation(deps);
      storeClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 500', () => {
      expect(responseStatusCode).to.equal(500);
    });
  });

  describe('store invitation a valid request', function(done) {
    let responseBody;
    let responseStatusCode;
    const testId = '12345';

    before((done) => {
      init();

      const params = { body: {
        actor: {
          organizationOID: 'organizationOID',
          associateOID: 'associateOID'
        },
        invitation: { client: { iid: 'testiid' } }
      } };

      deps.mongoRepo.collection.returns(
        new Promise((resolve,reject)=> {
          var mObject = {
            insert: function (body, callback) {
              callback(null, {ops: [{ _id: testId }]});
            },
            update: function (query, update, option, callback) {
              callback(null, {});
            }
          };
          resolve(mObject);
        })
      );
      let storeClientInvitation = new StoreClientInvitation(deps);
      storeClientInvitation.run(params)
        .then((actionResult) => {
          responseBody = actionResult;
          responseStatusCode = 200;
          done();
        })
        .catch((error) => {
          responseStatusCode = error;
          done();
        });
    });

    it ('response code is 200', () => {
      expect(responseStatusCode).to.equal(200);
    });

    it ('response body is valid', () => {
      expect(responseBody).to.exist;
      expect(responseBody).to.assert(testId);
    });

  });
});

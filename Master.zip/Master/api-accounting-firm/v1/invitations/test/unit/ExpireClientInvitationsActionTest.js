'use strict';
const _ = require('lodash');
const sinon = require('sinon');
const expect = require('chai').expect;
const jsonschema = new (require('jsonschema').Validator)();

const ExpireClientInvitations = require('../../actions/ExpireClientInvitations');
const Config = require('../../config');
const config = new Config();

describe('Expire Client Invitation Action Unit Test', function() {
  const sandbox = sinon.sandbox.create();
  let deps;
  let invitations;
  let invitationsWithErrors;

  function init() {
    deps = {
      logger: {
        error: sandbox.stub(),
        info: sandbox.stub()
      },
      mongoRepo: {
        collection: sandbox.stub()
      },
      config: config
    };

    invitations = [{
        "_id" : '58ebad2bb6154f09df38ddf0',
        "actor" : {
            "formattedName" : "Demo User",
            "associateOID" : "G3E1YK2CJPWBY6JN",
            "organizationOID" : "G3E1YK2CJPWBE19B",
            "applicationID" : {
                "idValue" : "JUDNDBDH6666"
            }
        },
        "invitation" : {
            "creationDateTime" : "2017-04-01T16:04:59.392Z",
            "dueDateTime" : "2017-04-03T16:04:59.392Z",
            "reminder" : {
                "dateTime" : 1492099499392.0,
                "isSend" : true
            },
            "invitationLabel" : "test1234",
            "invitationMessage" : "test1",
            "invitationEmail" : {
                "body" : "Body Example",
                "subject" : "Access Request from CPA Sample Firm"
            },
            "invitationStatusCode" : {
                "codeValue" : "open"
            },
            "grantedAccessPermissions" : {},
            "requestedAccessPermissions" : {
                "payrollReports" : true,
                "payrollApprove" : false,
                "taxFormsView" : true,
                "generalLedger" : true
            },
            "client" : {
                "iid" : "12345678"
            },
            "firm" : {
                "organizationOID" : "G3E1YK2CJPWBE19B",
                "legalNameAtTimeOfRequest" : null
            }
        }
    },
    {
        "_id" : '1543fd2bb6154f09df38ddf0',
        "actor" : {
            "formattedName" : "Demo User 2",
            "associateOID" : "G3E1YK2CJPWBY6JN",
            "organizationOID" : "G3E1YK2CJPWBE19B",
            "applicationID" : {
                "idValue" : "JUDNDBDH6666"
            }
        },
        "invitation" : {
            "creationDateTime" : "2017-04-01T16:04:59.392Z",
            "dueDateTime" : "2017-04-03T16:04:59.392Z",
            "reminder" : {
                "dateTime" : 1492099499392.0,
                "isSend" : true
            },
            "invitationLabel" : "test1234",
            "invitationMessage" : "test1",
            "invitationEmail" : {
                "body" : "Body Example",
                "subject" : "Access Request from CPA Sample Firm"
            },
            "invitationStatusCode" : {
                "codeValue" : "open"
            },
            "grantedAccessPermissions" : {},
            "requestedAccessPermissions" : {
                "payrollReports" : true,
                "payrollApprove" : false,
                "taxFormsView" : true,
                "generalLedger" : true
            },
            "client" : {
                "iid" : "12345678"
            },
            "firm" : {
                "organizationOID" : "G3E1YK2CJPWBE19B",
                "legalNameAtTimeOfRequest" : null
            }
        }
    }];

    invitations.each = function(cb) {
        const i = _.cloneDeep(this);
        i.push(null);
        _.forEach(i, (value, key) => {
            cb(null, value);
        });
    };
  }

  afterEach(() => {
    sandbox.restore();
  });

    // 1. Test for finding invitations, but no open invitations
    // 2. Test for finding no invitations
    // 3. Test for finding one open invitation
    // 4. Test for finding multiple open invitation
    // 4. Error with one of the invitations
    // 5. Error with connecting to mongo (saving)
    describe('retrieve invitations, no open invitations found', function(done) {
        let responseBody;
        let responseStatusCode;

        before((done) => {
            init();

            deps.mongoRepo.collection.returns(
                new Promise((resolve,reject)=> {
                    const mObject = {
                        find: function(body, callback) {
                            const newInvitations = invitations;
                            _.forEach(newInvitations, (item) => {
                                item.invitation.invitationStatusCode.codeValue = 'expired';
                            });
                            callback(null, newInvitations);
                        },
                        save: function(item, callback) {
                            callback(null);
                        }
                    };
                    resolve(mObject);
                })
            );
            let expireClientInvitations = new ExpireClientInvitations(deps);
            expireClientInvitations
                .run()
                .then((actionResult) => {
                    responseBody = actionResult;
                    responseStatusCode = 200;
                    done();
                })
                .catch((error) => {
                    responseStatusCode = error;
                    done();
                });
        });

        it ('response code is 200', () => {
            expect(responseStatusCode).to.equal(200);
        });

        it ('invitation count is 0', () => {
            expect(responseBody).to.exist;
            expect(responseBody).to.have.length.equal(0);
        });
    });

    describe('retrieve invitations, no invitations found', function(done) {
        let responseBody;
        let responseStatusCode;

        before((done) => {
            init();

            deps.mongoRepo.collection.returns(
                new Promise((resolve,reject)=> {
                    const mObject = {
                        find: function(body, callback) {
                            const newInvitations = invitations;
                            newInvitations.splice(0,2);
                            callback(null, newInvitations);
                        },
                        save: function(item, callback) {
                            callback(null);
                        }
                    };
                    resolve(mObject);
                })
            );
            let expireClientInvitations = new ExpireClientInvitations(deps);
            expireClientInvitations
                .run()
                .then((actionResult) => {
                    responseBody = actionResult;
                    responseStatusCode = 200;
                    done();
                })
                .catch((error) => {
                    responseStatusCode = error;
                    done();
                });
        });

        it ('response code is 200', () => {
            expect(responseStatusCode).to.equal(200);
        });

        it ('invitation count is 0', () => {
            expect(responseBody).to.exist;
            expect(responseBody).to.have.length.equal(0);
        });
    });

  describe('retrieve invitations, one open invitation', function(done) {
      let responseBody;
      let responseStatusCode;

      before((done) => {
          init();

          deps.mongoRepo.collection.returns(
              new Promise((resolve,reject)=> {
                  const mObject = {
                      find: function(body, callback) {
                          const newInvitations = invitations;
                          newInvitations.splice(0,1);
                        callback(null, newInvitations);
                      },
                      save: function(item, callback) {
                        callback(null);
                      }
                  };
                  resolve(mObject);
              })
          );
          let expireClientInvitations = new ExpireClientInvitations(deps);
          expireClientInvitations
          .run()
          .then((actionResult) => {
            responseBody = actionResult;
            responseStatusCode = 200;
            done();
          })
          .catch((error) => {
            responseStatusCode = error;
            done();
          });
      });

      it ('response code is 200', () => {
          expect(responseStatusCode).to.equal(200);
      });

      it ('invitation count is 1', () => {
        expect(responseBody).to.exist;
        expect(responseBody).to.have.length.equal(1);
      });
  });

  describe('retrieve invitations, multiple open invitations', function(done) {
    let responseBody;
    let responseStatusCode;

    before((done) => {
        init();

        deps.mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
                const mObject = {
                    find: function(body, callback) {
                        callback(null, invitations);
                    },
                    save: function(item, callback) {
                        callback(null);
                    }
                };
                resolve(mObject);
            })
        );
        let expireClientInvitations = new ExpireClientInvitations(deps);
        expireClientInvitations
            .run()
            .then((actionResult) => {
                responseBody = actionResult;
                responseStatusCode = 200;
                done();
            })
            .catch((error) => {
                responseStatusCode = error;
                done();
            });
    });

    it ('response code is 200', () => {
        expect(responseStatusCode).to.equal(200);
    });

    it ('invitation count is 2', () => {
        expect(responseBody).to.exist;
        expect(responseBody).to.have.length.equal(2);
    });
  });

  describe('error with invitation format', function(done) {
    let responseBody;
    let responseStatusCode;

    before((done) => {
        init();

        deps.mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
                const mObject = {
                    find: function(body, callback) {
                        const newInvitations = invitations;
                        newInvitations.splice(0,1);
                        delete newInvitations[0].invitation.invitationStatusCode;
                        callback(null, newInvitations);
                    },
                    save: function(item, callback) {
                        callback({ error: 'Cannot save' });
                    }
                };
                resolve(mObject);
            })
        );
        let expireClientInvitations = new ExpireClientInvitations(deps);
        expireClientInvitations
            .run()
            .then((actionResult) => {
                responseBody = actionResult;
                responseStatusCode = 200;
                done();
            })
            .catch((error) => {
                responseStatusCode = error;
                done();
            });
    });

    it ('response code is 500', () => {
        expect(responseStatusCode).to.equal(500);
    });
  });

  describe('error saving to MongoDB', function(done) {
    let responseBody;
    let responseStatusCode;

    before((done) => {
        init();

        deps.mongoRepo.collection.returns(
            new Promise((resolve,reject)=> {
                const mObject = {
                    find: function(body, callback) {
                        callback(null, invitations);
                    },
                    save: function(item, callback) {
                        callback({ error: 'Cannot save' });
                    }
                };
                resolve(mObject);
            })
        );
        let expireClientInvitations = new ExpireClientInvitations(deps);
        expireClientInvitations
            .run()
            .then((actionResult) => {
                responseBody = actionResult;
                responseStatusCode = 200;
                done();
            })
            .catch((error) => {
                responseStatusCode = error;
                done();
            });
    });

    it ('response code is 500', () => {
        expect(responseStatusCode).to.equal(500);
    });
  });

  // describe('Error in update of old invitation', function(done) {
  //   let responseBody;
  //   let responseStatusCode;
  //   const testId = '12345';
  //
  //   before((done) => {
  //     init();
  //
  //     const params = { body: {
  //       actor: {
  //         organizationOID: 'organizationOID',
  //         associateOID: 'associateOID'
  //       },
  //       invitation: { client: { iid: 'testiid' } }
  //     } };
  //
  //     deps.mongoRepo.collection.returns(
  //       new Promise((resolve,reject)=> {
  //         var mObject = {
  //           insert: function (body, callback) {
  //             callback(null, {ops: [{ _id: testId }]});
  //           },
  //           update: function (query, update, option, callback) {
  //             callback({ message: 'Error' }, {});
  //           }
  //         };
  //         resolve(mObject);
  //       })
  //     );
  //     let storeClientInvitation = new StoreClientInvitation(deps);
  //     storeClientInvitation.run(params)
  //       .then((actionResult) => {
  //         responseBody = actionResult;
  //         responseStatusCode = 200;
  //         done();
  //       })
  //       .catch((error) => {
  //         responseStatusCode = error;
  //         done();
  //       });
  //   });
  //
  //   it ('response code is 500', () => {
  //     expect(responseStatusCode).to.equal(500);
  //   });
  // });
  //
  // describe('Error in new invitation insert', function(done) {
  //   let responseBody;
  //   let responseStatusCode;
  //   const testId = '12345';
  //
  //   before((done) => {
  //     init();
  //
  //     const params = { body: {
  //       actor: {
  //         organizationOID: 'organizationOID',
  //         associateOID: 'associateOID'
  //       },
  //       invitation: { client: { iid: 'testiid' } }
  //     } };
  //
  //     deps.mongoRepo.collection.returns(
  //       new Promise((resolve,reject)=> {
  //         var mObject = {
  //           insert: function (body, callbackInsert) {
  //             callbackInsert({ message: 'insert error' }, { ops: [{ _id: testId }] });
  //           },
  //           update: function (query, update, option, callback) {
  //             callback(null, {});
  //           }
  //         };
  //         resolve(mObject);
  //       })
  //     );
  //     let storeClientInvitation = new StoreClientInvitation(deps);
  //     storeClientInvitation.run(params)
  //       .then((actionResult) => {
  //         responseBody = actionResult;
  //         responseStatusCode = 200;
  //         done();
  //       })
  //       .catch((error) => {
  //         responseStatusCode = error;
  //         done();
  //       });
  //   });
  //
  //   it ('response code is 500', () => {
  //     expect(responseStatusCode).to.equal(500);
  //   });
  // });
  //
  // describe('Error in load the collection', function(done) {
  //   let responseBody;
  //   let responseStatusCode;
  //   const testId = '12345';
  //
  //   before((done) => {
  //     init();
  //
  //     const params = { body: {
  //       actor: {
  //         organizationOID: 'organizationOID',
  //         associateOID: 'associateOID'
  //       },
  //       invitation: { client: { iid: 'testiid' } }
  //     } };
  //
  //     deps.mongoRepo.collection.returns(
  //       new Promise((resolve,reject)=> {
  //         reject({message:'Collection Error'});
  //       })
  //     );
  //     let storeClientInvitation = new StoreClientInvitation(deps);
  //     storeClientInvitation.run(params)
  //       .then((actionResult) => {
  //         responseBody = actionResult;
  //         responseStatusCode = 200;
  //         done();
  //       })
  //       .catch((error) => {
  //         responseStatusCode = error;
  //         done();
  //       });
  //   });
  //
  //   it ('response code is 500', () => {
  //     expect(responseStatusCode).to.equal(500);
  //   });
  // });
  //
});

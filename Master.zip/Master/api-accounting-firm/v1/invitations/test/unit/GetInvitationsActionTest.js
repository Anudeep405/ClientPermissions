'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const GetClientInvitations = require('../../actions/GetClientInvitations.js');
const util = require('util');

describe('Accounting Firm API Get Client Invitations tests', function() {
  const sandbox = sinon.sandbox.create();
  let deps = null;
  let mongoCollection;
  let validParams;

  const resolvePromise = function(output) {
    return new Promise((resolve, reject) => {
      resolve(output);
    });
  };

  function init() {
    validParams = {
      organizationOID: '1',
      associateOID: '2',
      invitationid: '111111111111'
    };
    deps = {
      logger: {
        error: sandbox.stub(),
        info: sandbox.stub()
      },
      mongoRepo: {
        collection: sandbox.stub()
      },
      mongodb: {
        ObjectID: sandbox.stub()
      },
      config: {}
    };
    deps.mongodb.ObjectID.isValid = sandbox.stub();
    mongoCollection = {
      aggregate: sandbox.stub()
    }
  }

  afterEach(() => {
    sandbox.restore();
  });


  describe('resolves promise on successful Mongo query', function(done) {
    let getClientInvitations;
    let result;
    let mongoResult;
    let emptyMongoResult;
    let promiseResult;

    before((done) => {
      init();

      mongoResult = [{something: true}];
      emptyMongoResult = [];
      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      mongoCollection.aggregate.yields(null, mongoResult);

      getClientInvitations = new GetClientInvitations(deps);
      getClientInvitations.run(validParams)
        .then((result) => {
          promiseResult = result;
          done();
        })
        .catch((err) => {
          done(err)
        })
    });

    it ('result is an array', () => {
      expect(promiseResult).to.be.a('array');
    });

    it ('it contains the response', () => {
      expect(promiseResult).to.equal(mongoResult);
    });

    it ('aggregate keys are in order', () => {
      expect(mongoCollection.aggregate.getCall(0).args[0][0]['$match']).to.exist;
      expect(mongoCollection.aggregate.getCall(0).args[0][1]['$sort']).to.exist;
      expect(mongoCollection.aggregate.getCall(0).args[0][2]['$limit']).to.exist;
      expect(mongoCollection.aggregate.getCall(0).args[0][3]['$project']).to.exist;
    });

  });


  describe('rejects promise on Mongo error', function(done) {
    let errorResult;
    let promiseResult;

    before((done) => {
      init();

      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      const mongoError = new Error('test');
      mongoCollection.aggregate.yields(mongoError, null);


      let getClientInvitations = new GetClientInvitations(deps);
      getClientInvitations.run(validParams)
        .then((result) => {
          done('resolved bad promise');
        })
        .catch((error) => {
          errorResult = error;
          done();
        })
    });

    it ('error is 500', () => {
      expect(errorResult).to.equal(500);
    });

    it ('logs the error', () => {
      expect(deps.logger.error.getCall(0).args[0]).to.contain('file="GetClientInvitationsAction" msg="Error returned by Mongo" error="test"');
    });
  });

  describe('rejects promise on exception', function(done) {
    let errorResult;
    let promiseResult;
    before((done) => {
      init();
      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      mongoCollection.aggregate.throws(new Error('test'));

      let getClientInvitations = new GetClientInvitations(deps);
      getClientInvitations.run(validParams)
        .then((result) => {
          done('resolved bad promise');
        })
        .catch((error) => {
          errorResult = error;
          done();
        })
    });

    it ('error is 500', () => {
      expect(errorResult).to.equal(500);
    });

    it ('logs the error', () => {
      expect(deps.logger.error.getCall(0).args[0]).to.contain('file="GetClientInvitationsAction" msg="Error accessing Mongo collection" error="test"');
    });
  });

  describe('returns successful on getAll with no invitation id', function(done) {
    let getClientInvitations;
    let result;
    let mongoResult;
    let promiseResult;

    before((done) => {
      init();
      mongoResult = [{something: true, dueDateTime: 0, invitationStatusCode: {codeValue: 'open'}}];

      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      mongoCollection.aggregate.yields(null, mongoResult);

      getClientInvitations = new GetClientInvitations(deps);

      validParams.invitationid = undefined;

      getClientInvitations.run(validParams)
        .then((result) => {
          promiseResult = result;
          done();
        })
        .catch((err) => {
          done(err)
        })
    });

    it ('it contains the response', () => {
      expect(promiseResult).to.equal(mongoResult);
    });

  });

  describe('returns successful on get by invitation id', function(done) {
    let getClientInvitations;
    let result;
    let mongoResult;
    let promiseResult;

    before((done) => {
      init();
      mongoResult = [{something: true, dueDateTime: 0, invitationStatusCode: {codeValue: 'open'}}];

      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      mongoCollection.aggregate.yields(null, mongoResult);

      getClientInvitations = new GetClientInvitations(deps);

      validParams.invitationid = 111111111111;

      getClientInvitations.run(validParams)
        .then((result) => {
          promiseResult = result;
          done();
        })
        .catch((err) => {
          done(err)
        })
    });

    it ('it contains the response', () => {
      expect(promiseResult).to.equal(mongoResult);
    });

  });


  describe('returns 204 on empty mongo result', function(done) {
    let getClientInvitations;
    let errorResult = 'result not set';
    let mongoResult;
    let promiseResult;

    before((done) => {
      init();
      mongoResult = [];

      deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
      mongoCollection.aggregate.yields(null, mongoResult);

      getClientInvitations = new GetClientInvitations(deps);

      getClientInvitations.run(validParams)
        .then((result) => {
          errorResult = result;
          done();
        })
        .catch(() => {
          done('resolved bad promise');
        })
    });


    it ('error is 204 when no results', () => {
      expect(errorResult).to.equal(void(0));
    });

  });

  // describe('returns expired invitation status when appropriate', function(done) {
  //   let getClientInvitations;
  //   let result;
  //   let mongoResult;
  //   let promiseResult;
  //
  //   before((done) => {
  //     init();
  //     mongoResult = [{something: true, dueDateTime: 0, invitationStatusCode: {codeValue: 'open'}}];
  //
  //     deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
  //     mongoCollection.aggregate.yields(null, mongoResult);
  //
  //     getClientInvitations = new GetClientInvitations(deps);
  //
  //     getClientInvitations.run(validParams)
  //       .then((result) => {
  //         promiseResult = result;
  //         done();
  //       })
  //       .catch((err) => {
  //         done(err)
  //       })
  //   });
  //
  //   it ('it contains the response', () => {
  //     expect(promiseResult).to.equal(mongoResult);
  //   });
  //
  //   it ('reached code for expiring the status', () => {
  //     expect(deps.logger.info.getCall(0).args[0]).to.contain('test: returns expired invitation when appropriate');
  //   });
  //
  // });
});
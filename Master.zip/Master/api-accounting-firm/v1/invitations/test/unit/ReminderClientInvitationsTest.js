'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const ReminderClientInvitationHandler = require('../../handlers/ReminderClientInvitation');
const UpdateReminderInvitationsAction = require('../../actions/UpdateReminderInvitations');
const GetReminderInvitationsAction = require('../../actions/GetReminderInvitations');
const SendReminderInvitationsAction = require('../../actions/SendReminderInvitations');
const ConfigSetting = require('../../config');
const config = new ConfigSetting();

describe('Reminder Client Invitations Unit Test - ', function() {

  const sandbox = sinon.sandbox.create();
  const mongoRepo = {
    collection: sandbox.stub()
  };
  const loggerStub = {
    error: sandbox.stub(),
    info: sandbox.stub()
  };
  let deps;
  const resolvePromise = function(output) {
    return new Promise((resolve, reject) => {
      resolve(output);
    });
  }

  const rejectPromise = function(output) {
    return new Promise((resolve, reject) => {
      reject(output);
    });
  }
  const RequestApi = {
    run: sandbox.stub()
  };

  function init() {
    deps = {
      mongoRepo: mongoRepo,
      mongodb: {
        ObjectID: function (id) {
          return id;
        }
      },
      config: config,
      GetReminderInvitations: GetReminderInvitationsAction,
      UpdateReminderInvitations: UpdateReminderInvitationsAction,
      SendReminderInvitations: SendReminderInvitationsAction,
      RequestApi: sandbox.stub()
    };
    deps.RequestApi.returns(RequestApi);
  }

  describe('handles a valid request:', function(done) {
    let responseBody;
    let statusCode;
    let stubRequest;

    before((done) => {
      init();
      stubRequest = {
        params: {},
        headers: {},
        body: {},
        logger: loggerStub
      };
      mongoRepo.collection.returns(
        new Promise((resolve, reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback(null, { result: { nModified: 1 }});
            },
            find: function () {
              return {
                toArray: function (callback) {
                  callback(null, []);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      RequestApi.run.returns(resolvePromise({}));

      let reminderClientInvitationHandler = new ReminderClientInvitationHandler(deps);
      let handler = reminderClientInvitationHandler.create();
      handler(stubRequest, function (response, code) {
          responseBody = response;
          statusCode = code;
          done();
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      expect(responseBody.reminder.send).to.equal(1);
    });
  });

  describe('find caught error:', function(done) {
    let responseBody;
    let statusCode;
    let stubRequest;

    before((done) => {
      init();
      stubRequest = {
        params: {},
        headers: {},
        body: {},
        logger: loggerStub
      };
      mongoRepo.collection.returns(
        new Promise((resolve, reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback({ message: 'update error!!!' });
            },
            find: function () {
              return {
                toArray: function (callback) {
                  callback(null, []);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      RequestApi.run.returns(resolvePromise({}));

      let reminderClientInvitationHandler = new ReminderClientInvitationHandler(deps);
      let handler = reminderClientInvitationHandler.create();
      handler(stubRequest, function (response, code) {
        responseBody = response;
        statusCode = code;
        done();
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('update cought error:', function(done) {
    let responseBody;
    let statusCode;
    let stubRequest;

    before((done) => {
      init();
      stubRequest = {
        params: {},
        headers: {},
        body: {},
        logger: loggerStub
      };
      mongoRepo.collection.returns(
        new Promise((resolve, reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback(null, { result: { nModified: 1 }});
            },
            find: function () {
              return {
                toArray: function (callback) {
                  callback({ message: 'find error!!!' });
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      RequestApi.run.returns(resolvePromise({}));

      let reminderClientInvitationHandler = new ReminderClientInvitationHandler(deps);
      let handler = reminderClientInvitationHandler.create();
      handler(stubRequest, function (response, code) {
        responseBody = response;
        statusCode = code;
        done();
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(500);
    });
  });

  describe('unknown update caught error:', function(done) {
    let responseBody;
    let statusCode;
    let stubRequest;

    before((done) => {
      init();
      stubRequest = {
        params: {},
        headers: {},
        body: {},
        logger: loggerStub
      };
      mongoRepo.collection.returns(
        new Promise((resolve, reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback(null, null);
            },
            find: function () {
              return {
                toArray: function (callback) {
                  callback(null, []);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      RequestApi.run.returns(resolvePromise({}));

      let reminderClientInvitationHandler = new ReminderClientInvitationHandler(deps);
      let handler = reminderClientInvitationHandler.create();
      handler(stubRequest, function (response, code) {
        responseBody = response;
        statusCode = code;
        done();
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(204);
    });
  });

  describe('handles a valid request - Email send Fail:', function(done) {
    let responseBody;
    let statusCode;
    let stubRequest;

    before((done) => {
      init();
      stubRequest = {
        params: {},
        headers: {},
        body: {},
        logger: loggerStub
      };
      mongoRepo.collection.returns(
        new Promise((resolve, reject)=> {
          var mObject = {
            update: function (query, update, option, callback) {
              callback(null, { result: { nModified: 1 }});
            },
            find: function () {
              return {
                toArray: function (callback) {
                  callback(null, []);
                }
              }
            }
          };
          resolve(mObject);
        })
      );
      RequestApi.run.returns(rejectPromise({}));

      let reminderClientInvitationHandler = new ReminderClientInvitationHandler(deps);
      let handler = reminderClientInvitationHandler.create();
      handler(stubRequest, function (response, code) {
        responseBody = response;
        statusCode = code;
        done();
      });
    });

    it ('response body is valid', () => {
      expect(statusCode).to.equal(200);
      expect(responseBody).to.exist;
      expect(responseBody.reminder.send).to.equal(1);
    });
  });

});

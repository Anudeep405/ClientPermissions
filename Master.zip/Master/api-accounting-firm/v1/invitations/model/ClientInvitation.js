'use strict';

const _ = require('lodash');

module.exports = class ClientInvitationModel {
  constructor(requestBody, config) {
    this.requestBody = requestBody;
    this.config = config;

    this.iid = requestBody;
    this.fein = requestBody;
  }

  get mongoInsert() {
    const today = new Date();
    const dueDateTime = new Date(today);
    dueDateTime.setDate(dueDateTime.getDate() + this.config.INVITATION_EXPIRE_DAY);
    const reminderDateTime = new Date(today);
    reminderDateTime.setDate(reminderDateTime.getDate() + this.config.INVITATION_REMIND_DAY);

    return {
      actor: this.requestBody.events[0].actor,
      invitation: {
        creationDateTime: today.toISOString(),
        dueDateTime: dueDateTime.toISOString(),
        reminder: {
          dateTime: reminderDateTime.valueOf(),
          isSend: false
        },
        invitationLabel: this.requestBody.events[0].data.transform.invitation.invitationLabel,
        invitationMessage: this.requestBody.events[0].data.transform.invitation.invitationMessage,
        invitationEmail: this.requestBody.events[0].data.transform.invitation.invitationEmail,
        invitationStatusCode: {
          codeValue: 'open'
        },
        statusDetailCode: {
          codeValue: ''
        },
        grantedAccessPermissions: {},
        requestedAccessPermissions: this.requestBody.events[0].data.transform.invitation.accessPermissions,
        client: this.requestBody.events[0].data.eventContext.client,
        firm: this.requestBody.events[0].data.eventContext.firm
      }
    };
  }

  get emailInvitationBody() {
    return {
      events: [{
        serviceCategoryCode: {
          codeValue: 'notifications'
        },
        eventNameCode: {
          codeValue: 'emails.send'
        },
        actor: {
          applicationID: {
            idValue: 'accounting-firm/v1/client-access-invitation.create'
          }
        },
        data: {
          transform: {
            eventStatusCode: {
              codeValue: 'submit'
            },
            emails: []
          }
        }
      }]
    };
  }

  get addAccountantBody() {
    return {
      events: [{
        serviceCategoryCode: {
          codeValue: 'company'
        },
        eventNameCode: {
          codeValue: 'accountant.add'
        },
        actor: {
          formattedName: this.requestBody.events[0].actor.formattedName,
          associateOID: this.requestBody.events[0].actor.associateOID,
          organizationOID: this.requestBody.events[0].actor.organizationOID,
          applicationID: {
            idValue: 'accounting-firm/v1/client-access-invitation.accept'
          }
        },
        data: {
          eventContext: {
            firm: {
              organizationOID: ''
            },
            client: {
              organizationOID: this.requestBody.events[0].actor.organizationOID
            }
          },
          transform: {
            accessPermissions: this.requestBody.events[0].data.transform.invitation.grantedAccessPermissions
          }
        }

      }]
    };
  }

  get mongoUpdateInvitation() {
    return {
      'invitation.responseDateTime': new Date().toISOString(),
      'invitation.invitationStatusCode.codeValue': 'accepted',
      'invitation.responseActor': this.requestBody.events[0].actor,
      'invitation.grantedAccessPermissions': this.requestBody.events[0].data.transform.invitation.grantedAccessPermissions,
      'invitation.tos': this.requestBody.events[0].data.transform.invitation.tos
    };
  }

  get mongoRejectInvitation() {
    return {
      'invitation.responseDateTime': new Date().toISOString(),
      'invitation.invitationStatusCode.codeValue': 'rejected',
      'invitation.responseActor': this.requestBody.events[0].actor
    };
  }

  get emailAcceptBody() {
    return {
      events: [{
        serviceCategoryCode: {
          codeValue: 'notifications'
        },
        eventNameCode: {
          codeValue: 'emails.send'
        },
        actor: {
          applicationID: {
            idValue: 'accounting-firm/v1/client-access-invitation.accept'
          }
        },
        data: {
          transform: {
            eventStatusCode: {
              codeValue: 'submit'
            },
            emails: [{
              recipient: {
                name: '',
                email: ''
              },
              subject: this.requestBody.events[0].data.transform.invitation.invitationResponseEmail.subject,
              body: this.requestBody.events[0].data.transform.invitation.invitationResponseEmail.body
            }]
          }
        }
      }]
    };
  }

  get tosAcceptBody() {
    return {
      events: [{
        serviceCategoryCode: {
          codeValue: 'legal'
        },
        eventNameCode: {
          codeValue: 'tos.accept'
        },
        actor: {
          formattedName: this.requestBody.events[0].actor.formattedName,
          associateOID: this.requestBody.events[0].actor.associateOID,
          organizationOID: this.requestBody.events[0].actor.organizationOID,
          applicationID: {
            idValue: 'accounting-firm/v1/client-access-invitation.accept'
          }
        },
        data: {
          transform: {
            eventStatusCode: {
              codeValue: 'submit'
            },
            tos: [this.requestBody.events[0].data.transform.invitation.tos]
          }
        }

      }]
    };
  }

  get successAcceptResponse() {
    return {
      invitation: {
        invitationStatusCode: {
          codeValue: 'accepted'
        },
        grantedAccessPermissions: this.requestBody.events[0].data.transform.invitation.grantedAccessPermissions,
        tos: this.requestBody.events[0].data.transform.invitation.tos
      },
      invitationResponseEmail: this.requestBody.events[0].data.transform.invitationResponseEmail
    };
  }

  get successResponse() {
    return {
      invitation: {
        invitationLabel: this.requestBody.events[0].data.transform.invitation.invitationLabel,
        invitationStatusCode: {
          codeValue: 'open'
        },
        statusDetailCode: {
          codeValue: null
        },
        accessPermissions: this.requestBody.events[0].data.transform.invitation.accessPermissions,
        invitationMessage: this.requestBody.events[0].data.transform.invitation.invitationMessage,
        invitationEmail: this.requestBody.events[0].data.transform.invitation.invitationEmail
      }
    };
  }

  getFailResponse(message, userMessage) {
    return {
      confirmMessage: {
        resourceMessages: [{
          processMessages: [{
            messageTypeCode: {
              codeValue: 'error',
              shortName: message
            },
            userMessage: userMessage ? { messageTxt: userMessage } : undefined
          }]
        }]
      }
    };
  }

  set iid(body) {
    this._iid = _.get(body, 'events[0].data.eventContext.client.iid');
  }

  get iid() {
    return this._iid;
  }

  set fein(body) {
    this._fein = _.get(body, 'events[0].data.eventContext.client.fein');
  }

  get fein() {
    return this._fein;
  }
};

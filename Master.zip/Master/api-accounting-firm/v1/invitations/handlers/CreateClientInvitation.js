'use strict';
const ClientInvitationModel = require('../model/ClientInvitation');
const jsonschema = new (require('jsonschema').Validator)();
const docs = require('@adp-sir/api-accounting-firm-docs').create();
const _ = require('lodash');

const ALREADY_A_CLIENT_ERROR = 'already-a-client';
const INVALID_REQUEST_ERROR = 'invalid-request';
const MULTI_COMPANY_MATCH_ERROR = 'multi-company-match';
const COMPANY_NOT_FOUND_BY_IID = 'company-not-found-by-iid';
const COMPANY_NOT_FOUND_BY_FEIN = 'company-not-found-by-fein';
const VALIDATION_FAILED = 'validation-failed';
const EMAIL_NOT_FOUND_FAILED = 'email-not-found-failed';

class Handler {
  constructor(deps, req, event, reply) {
    this.model = null;
    this.cOrgoid = null;
    this.invitationID = null;
    this.firmName = null;
    this.firmState = null;
    this.firmIID = null;
    this.firmServiceRegion = null;
    this.statusDetailCode = null;

    this.req = req;
    this.reply = reply;

    this.logger = req.logger;
    this.config = deps.config;
    this.mongoRepo = deps.mongoRepo;

    this.requestApi = new deps.RequestApi(this.logger, this.req);

    this.storeClientInvitation = new deps.StoreClientInvitation({
      logger: this.logger,
      config: this.config,
      mongoRepo: this.mongoRepo
    });
  }

  run() {
    this.createModel(this.req)
      .then(() => this.validateRequest(this.req))
      .then(() => this.getFirmNameAndState(this.req))
      .then(() => this.getFirmServiceRegion(this.req))
      .then(() => this.getCompanyInfo(this.req))
      .then(() => this.searchExistenceOfIIDorEIN(this.req))
      .then(() => this.searchExistingClients(this.req))
      .then(() => this.getClientContacts(this.req))
      .then((recipients) => this.saveInvitation(recipients))
      .then((recipients) => this.sendNotification(this.req, recipients))
      .then(() => this.complete())
      .catch((error) => this.fail(error));
  }

  updateModel(model) {
    const saveModel = model;
    saveModel.invitation.firm.legalNameAtTimeOfRequest = this.firmName;
    saveModel.invitation.firm.state = this.firmState;
    saveModel.invitation.firm.serviceRegion = this.firmServiceRegion;
    saveModel.invitation.firm.iid = (this.firmIID && this.firmIID.toString()) || null;
    saveModel.invitation.client.organizationOID = this.cOrgoid;

    return saveModel;
  }

  createModel() {
    return new Promise((resolve, reject) => {
      try {
        this.model = new ClientInvitationModel(this.req.body, this.config);
        return resolve();
      } catch (error) {
        return reject(error);
      }
    });
  }

  getFirmNameAndState() {
    return new Promise((resolve, reject) => {
      const url = this.config.GET_FIRM_BY_ORGOID_API_URL.replace(':orgoid', this.req.headers.orgoid);
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        consumeraoid: this.req.headers.consumeraoid,
        'content-type': 'application/json'
      };
      return this.requestApi.run(url, 'GET', headers, null)
        .then((result) => {
          // temporary fix for bug on company-addresses schema break
          // next time this file is changed, replace the 4 lines below with the following:
          const firmAddress = result.contacts.legalAddress && result.contacts.legalAddress.address ? result.contacts.legalAddress.address : null;
          const firmStateKey = firmAddress ? firmAddress[_.findKey(firmAddress, { subdivisionType: 'STATE' })] : null;

          if (firmStateKey) {
            this.firmState = firmStateKey.codeValue;
          } else {
            this.logger.warn('file=CreateClientInvitation" method="getFirmNameAndState" msg="Could not get firm state"');
          }

          this.firmName = _.get(result, 'contacts.legalAddress.name') || _.get(result, 'contacts.legal.name');
          if (!this.firmName) {
            return reject('Could not get firm name');
          }
          return resolve();
        })
        .catch((error) => reject(error));
    });
  }

  getFirmServiceRegion() {
    return new Promise((resolve, reject) => {
      const url = this.config.GET_FIRM_SERVICE_REGION_BY_ORGOID_API_URL.replace(':orgoid', this.req.headers.orgoid);
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        consumeraoid: this.req.headers.consumeraoid,
        'content-type': 'application/json'
      };
      return this.requestApi.run(url, 'GET', headers, null)
        .then((result) => {
          const contacts = result && result.supportContacts ? result.supportContacts : {};
          const firmServiceRegionKey = contacts[_.findKey(contacts, { stateCode: { codeValue: this.firmState } })];
          if (firmServiceRegionKey) {
            this.firmServiceRegion = firmServiceRegionKey.regionCode.codeValue;
          }

          if (!this.firmServiceRegion) {
            this.logger.warn('file=CreateClientInvitation" method="getFirmServiceRegion" msg="Could not get firm service region"');
          }
          return resolve();
        })
        .catch((error) => reject(error));
    });
  }

  getCompanyInfo() {
    return new Promise((resolve, reject) => {
      const url = this.config.GET_FIRM_INFO_API_URL;
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        consumeraoid: this.req.headers.consumeraoid,
        'content-type': 'application/json'
      };

      return this.requestApi.run(url, 'GET', headers, null)
        .then((result) => {
          this.firmIID = result.client && result.client.installationID ? result.client.installationID : {};

          if (!this.firmIID) {
            this.logger.warn('file=CreateClientInvitation" method="getCompanyInfo" msg="Could not get firm IID"');
          }
          return resolve();
        })
       .catch((error) => reject(error));
    });
  }

  searchExistenceOfIIDorEIN() {
    return new Promise((resolve, reject) => {
      const url = this.model.iid ?
                  this.config.GET_ORGOID_BY_IID_API_URL.replace(':iid', this.model.iid) :
                  this.config.GET_ORGOID_BY_FEIN_API_URL.replace(':fein', this.model.fein);
      const method = 'GET';
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        'content-type': 'application/json'
      };
      const COMPANY_NOT_FOUND = this.model.iid ? COMPANY_NOT_FOUND_BY_IID : COMPANY_NOT_FOUND_BY_FEIN;

      return this.requestApi.run(url, method, headers, null)
        .then((result) => {
          if (result.companies.length === 1) {
            this.cOrgoid = result.companies[0].organizationOID;
            return resolve();
          } else if (result.companies.length > 1) {
            return reject(MULTI_COMPANY_MATCH_ERROR);
          }
          return reject(COMPANY_NOT_FOUND);
        })
        .catch(() => {
          // We're creating an invitation for a 500 until bug DE288301 is fixed
          // should be 404 only
          reject(COMPANY_NOT_FOUND);
        });
    });
  }

  searchExistingClients() {
    return new Promise((resolve, reject) => {
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        'content-type': 'application/json',
        'cache-control': 'no-cache' // ensures we pick up a fresh copy of the client list
      };
      return this.requestApi.run(this.config.GET_CLIENTS_API_URL, 'GET', headers, null)
        .then((result) => {
          for (let i = 0; i < result.clients.length; i++) {
            if (result.clients[i].organizationOID === this.cOrgoid) {
              this.logger.warn('file=CreateClientInvitation" method="searchExistingClients" msg="failed request because of existing client"');
              return reject(ALREADY_A_CLIENT_ERROR);
            }
          }
          return resolve();
        })
        .catch((error) => reject(error));
    });
  }

  getClientContacts() {
    return new Promise((resolve, reject) => {
      const url = this.config.GET_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', this.cOrgoid);
      const headers = {
        orgoid: this.req.headers.orgoid,
        associateoid: this.req.headers.associateoid,
        'content-type': 'application/json'
      };
      return this.requestApi.run(url, 'GET', headers, null)
        .then((result) => {
          const recipients = [];
          for (let i = 0; i < result.contacts.length; i++) {
            const recipientName = result.contacts[i].firstName + ' ' + result.contacts[i].lastName;
            for (let j = 0; j < result.contacts[i].communication.emails.length; j++) {
              const recipientEmail = result.contacts[i].communication.emails[j].emailUri;
              recipients.push({
                name: recipientName,
                email: recipientEmail
              });
            }
          }
          resolve(recipients);
        })
        .catch((error) => reject(error));
    });
  }

  saveInvitation(recipients) {
    return new Promise((resolve, reject) => {
      const saveModel = this.updateModel(this.model.mongoInsert);
      saveModel.invitation.client.recipients = recipients;

      if (!recipients.length) {
        return reject(EMAIL_NOT_FOUND_FAILED);
      }

      return this.storeClientInvitation.run({ body: saveModel })
        .then((invitID) => {
          this.invitationID = invitID;
          return resolve(recipients);
        })
        .catch((error) => reject(error));
    });
  }

  sendNotification(req, recipients) {
    return new Promise((resolve, reject) => {
      const headers = {
        orgoid: this.req.headers.orgoid,
        consumeraoid: this.req.headers.associateoid,
        associateoid: this.req.headers.associateoid,
        'content-type': 'application/json'
      };
      const body = this.model.emailInvitationBody;
      body.events[0].actor.associateOID = this.req.headers.orgoid;
      body.events[0].actor.organizationOID = this.req.headers.associateoid;
      body.events[0].actor.formattedName = this.req.body.events[0].actor.formattedName;
      const emailBody = this.req.body.events[0].data.transform.invitation.invitationEmail.body.replace('%invitationID%', this.invitationID).replace('%expireDay%', this.config.INVITATION_EXPIRE_DAY);
      const emailSubject = this.req.body.events[0].data.transform.invitation.invitationEmail.subject;

      const emails = [];
      for (let i = 0; i < recipients.length; i++) {
        emails.push({ recipient: recipients[i], subject: emailSubject, body: emailBody });
      }

      body.events[0].data.transform.emails = emails;
      return this.requestApi.run(this.config.NOTIFICATION_EMAIL_SEND_API_URL, 'POST', headers, body)
        .then(() => {
          resolve();
        })
        .catch((error) => {
          this.logger.error(`file="CreateClientInvitation" method="sendNotification" msg="email failed" error="${error}"`);
          return reject(400);
        });
    });
  }

  validateRequest() {
    return new Promise((resolve, reject) => {
      if (!this.req.headers.orgoid || !this.req.headers.associateoid) {
        this.logger.error('file="CreateClientInvitation" method="validateRequest" msg="missing headers"');
        return reject(VALIDATION_FAILED);
      }

      if (!this.model.iid && !this.model.fein) {
        this.logger.error('file="CreateClientInvitation" method="validateRequest" msg="missing iid or fein"');
        return reject(VALIDATION_FAILED);
      }

      return docs.getRequestSchema(this.config.INVITATION_CREATE_API_PATH)
        .then((schema) => {
          const validation = jsonschema.validate(this.req.body, schema);
          if (!validation.valid) {
            this.logger.error(`file="CreateClientInvitation" method="validateRequest" msg="invalid request body" error="${JSON.stringify(validation.errors)}"`);
            return reject(VALIDATION_FAILED);
          }
          return resolve();
        })
        .catch((error) => {
          this.logger.error(`file="CreateClientInvitation" method="validateRequest" msg="load the request schema body" error="${error}"`);
          return reject(400);
        });
    });
  }

  fail(code) {
    let statusCode = code;

    if (code === MULTI_COMPANY_MATCH_ERROR) {
      return this.reply.failed(this.model.getFailResponse(
        MULTI_COMPANY_MATCH_ERROR,
        'Unable to create invitation. There are multiple company matches for the provided search term.'
      ), 422);
    } else if (code === COMPANY_NOT_FOUND_BY_FEIN || code === COMPANY_NOT_FOUND_BY_IID || code === EMAIL_NOT_FOUND_FAILED) {
      this.logger.error(`file="CreateClientInvitation.js" method="fail" code="${code}" invitationID="${this.invitationID}" clientIID="${this.model.iid || ''}"`);

      // Update model and save invitation with updated statusCode
      const saveModel = this.updateModel(this.model.mongoInsert);
      saveModel.invitation.statusDetailCode.codeValue = code;

      const resResult = this.model.successResponse;

      return this.storeClientInvitation.run({ body: saveModel })
        .then((invitID) => {
          resResult.invitation.invitationID = invitID;
          return this.reply.completed(resResult, 200);
        })
        .catch(() => {
          this.reply.completed(resResult, 200);
        });
    } else if (code === VALIDATION_FAILED) {
      return this.reply.failed(this.model.getFailResponse(INVALID_REQUEST_ERROR), 400);
    } else if (code === ALREADY_A_CLIENT_ERROR) {
      return this.reply.failed(this.model.getFailResponse(ALREADY_A_CLIENT_ERROR), 400);
    } else if (code === 400) {
      return this.reply.failed(500);
    } else if (typeof code !== 'number') {
      statusCode = 500;
    }

    this.logger.error(`file="CreateClientInvitation" method="fail" msg="failed request with code" statusCode=${statusCode} code=${code}`);
    return this.reply.failed(statusCode);
  }

  complete() {
    this.logger.info(`file="CreateClientInvitation" msg="success" invitationID="${this.invitationID}" inviteMethod="${this.model.iid ? 'IID' : 'FEIN'}" clientIID="${this.model.iid || ''}"`);

    const resResult = this.model.successResponse;
    resResult.invitation.invitationID = this.invitationID;
    return this.reply.completed(resResult, 200);
  }
}

class CreateClientInvitation {
  constructor(deps) {
    this.deps = deps;
  }

  create() {
    return (req, event, reply) => {
      const handler = new Handler(this.deps, req, event, reply);
      handler.run();
    };
  }
}

module.exports = CreateClientInvitation;


'use strict';
const ClientInvitationModel = require('../model/ClientInvitation');

class Handler {
  constructor(deps, req, event, reply) {
    this.req = req;
    this.reply = reply;

    this.logger = req.logger;
    this.config = deps.config;
    this.mongoRepo = deps.mongoRepo;
    this.mongodb = deps.mongodb;

    this.model = null;
    this.invitation = null;
    this.invitationID = null;

    this.requestApi = new deps.RequestApi(this.logger, this.req);

    this.loadInvitation = new deps.LoadInvitation({
      logger: this.logger,
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb
    });

    this.acceptClientInvitation = new deps.AcceptClientInvitation({
      logger: this.logger,
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb
    });
  }

  run() {
    try {
      this.model = new ClientInvitationModel(this.req.body, this.config);

      this.validateRequest()
        .then(() => this.getInvitation())
        .then(() => this.acceptLegal())
        .then(() => this.addAccountAccess())
        .then(() => this.storeAcceptInvitation())
        .then(() => this.getUserContacts())
        .then((recipient) => this.sendNotification(recipient))
        .then(() => this.complete())
        .catch((error) => this.fail(error));
    } catch (err) {
      this.logger.error(`file="AcceptClientInvitation" method="run" msg="OverAll: failed" error="${err}"`);
      this.fail(500);
    }
  }

  validateRequest() {
    return new Promise((resolve, reject) => {
      if (!this.req.headers.orgoid || !this.req.headers.associateoid) {
        this.logger.error('file="AcceptClientInvitation" method="validateRequest" msg="missing headers"');
        return reject(400);
      }
      if (!this.req.body.events[0].data.eventContext.invitation.invitationID) {
        this.logger.error('file="AcceptClientInvitation" method="validateRequest" msg="missing invitationID"');
        return reject(400);
      }
      this.invitationID = this.req.body.events[0].data.eventContext.invitation.invitationID;
      return resolve();
    });
  }

  getInvitation() {
    return new Promise((resolve, reject) => {
      const organizationOID = this.req.body.events[0].actor.organizationOID;
      return this.loadInvitation.run(this.invitationID, organizationOID)
        .then((invitData) => {
          this.invitation = invitData;
          resolve();
        })
        .catch((error) => reject(error));
    });
  }

  acceptLegal() {
    return new Promise((resolve, reject) => {
      const headers = {
        ORGOID: this.req.headers.orgoid,
        ASSOCIATEOID: this.req.headers.associateoid,
        CONSUMERAOID: this.req.headers.associateoid,
        'CONTENT-TYPE': 'application/json'
      };
      return this.requestApi.run(this.config.ACCEPT_LEGAL_API_URL, 'POST', headers, this.model.tosAcceptBody)
        .then(() => resolve())
        .catch((error) => {
          this.logger.error(`file="AcceptClientInvitation" method="acceptLegal" error="${error}"`);
          return reject(500);
        });
    });
  }

  addAccountAccess() {
    return new Promise((resolve, reject) => {
      const headers = {
        ORGOID: this.req.headers.orgoid,
        ASSOCIATEOID: this.req.headers.associateoid,
        CONSUMERAOID: this.req.headers.associateoid,
        'CONTENT-TYPE': 'application/json'
      };
      const body = this.model.addAccountantBody;
      body.events[0].data.eventContext.firm.organizationOID = this.invitation.actor.organizationOID;
      return this.requestApi.run(this.config.ADD_ACCOUNTANT_API_URL, 'POST', headers, body)
        .then(() => resolve())
        .catch((error) => {
          this.logger.error(`file="AcceptClientInvitation" method="addAccountAccess" error="${error}"`);
          return reject(500);
        });
    });
  }

  storeAcceptInvitation() {
    return new Promise((resolve, reject) => {
      const params = {
        invitationid: this.invitation._id,
        set: this.model.mongoUpdateInvitation
      };
      return this.acceptClientInvitation.run(params)
        .then(() => resolve())
        .catch((error) => reject(error));
    });
  }

  getUserContacts() {
    return new Promise((resolve, reject) => {
      const url = this.config.GET_USER_CONTACTS_BY_ORGOID_API_URL.replace(':orgoid', this.invitation.actor.associateOID);
      const headers = {
        ORGOID: this.invitation.actor.organizationOID,
        ASSOCIATEOID: this.invitation.actor.associateOID,
        CONSUMERAOID: this.invitation.actor.associateOID,
        'CONTENT-TYPE': 'application/json'
      };
      return this.requestApi.run(url, 'GET', headers, null)
        .then((sResult) => {
          const recipient = { name: sResult.contact.legalName.givenName + ' ' + sResult.contact.legalName.familyName };
          recipient.email = sResult.contact.communication.emails[0].emailUri;
          return resolve(recipient);
        })
        .catch((error) => {
          this.logger.error(`file="AcceptClientInvitation" method="getUserContacts" error="${error}"`);
          return reject(501);
        });
    });
  }

  sendNotification(recipient) {
    return new Promise((resolve, reject) => {
      if (!this.req.body.events[0].data.transform.invitation.invitationResponseEmail) {
        return reject(501);
      }
      const headers = {
        ORGOID: this.req.headers.orgoid,
        CONSUMERAOID: this.req.headers.associateoid,
        ASSOCIATEOID: this.req.headers.associateoid,
        'CONTENT-TYPE': 'application/json'
      };
      const body = this.model.emailAcceptBody;
      body.events[0].actor.associateOID = this.req.headers.orgoid;
      body.events[0].actor.organizationOID = this.req.headers.associateoid;
      body.events[0].actor.formattedName = this.req.body.events[0].actor.formattedName;
      body.events[0].data.transform.emails[0].recipient = recipient;
      // body.events[0].data.transform.emails[0].cc = { name: 'Indresh Kumar', email: 'indresh.kumar@adp.com' };
      return this.requestApi.run(this.config.NOTIFICATION_EMAIL_SEND_API_URL, 'POST', headers, body)
        .then(() => {
          resolve();
        })
        .catch((error) => {
          this.logger.error(`file="AcceptClientInvitation" method="sendNotification" msg="email failed" error="${error}"`);
          reject(501);
        });
    });
  }

  fail(code) {
    let statusCode = code;
    if (typeof code !== 'number') {
      statusCode = 500;
    }
    this.logger.error(`file="AcceptClientInvitation" method="fail" msg="failed request with code" statusCode="${statusCode}" code="${code}" invitationID=${this.invitationID}`);
    if (code === 501) {
      return this.reply.completed(this.model.successAcceptResponse, 200);
    }
    return this.reply.failed(statusCode);
  }

  complete() {
    const orgoid = this.req.headers.orgoid;
    const associateoid = this.req.headers.associateoid;

    this.logger.info(`file="AcceptClientInvitation" method="complete" msg="success" invitationID=${this.invitationID} orgoid=${orgoid} associateoid=${associateoid}`);
    return this.reply.completed(this.model.successAcceptResponse, 200);
  }
}

class AcceptClientInvitation {
  constructor(deps) {
    this.deps = deps;
  }

  create() {
    return (req, event, reply) => {
      const handler = new Handler(this.deps, req, event, reply);
      handler.run();
    };
  }
}

module.exports = AcceptClientInvitation;

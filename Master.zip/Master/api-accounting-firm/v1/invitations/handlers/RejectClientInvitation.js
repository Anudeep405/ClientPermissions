'use strict';
const ClientInvitationModel = require('../model/ClientInvitation');

class Handler {

  constructor(deps, req, event, reply) {
    this.req = req;
    this.reply = reply;

    this.logger = req.logger;
    this.config = deps.config;
    this.mongoRepo = deps.mongoRepo;
    this.mongodb = deps.mongodb;

    this.model = null;
    this.invitationID = null;

    this.rejectClientInvitation = new deps.RejectClientInvitation({
      logger: this.logger,
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb
    });
  }

  run() {
    try {
      this.model = new ClientInvitationModel(this.req.body, this.config);

      this.validateRequest()
        .then(() => this.storeRejectInvitation())
        .then(() => this.complete())
        .catch((error) => this.fail(error));
    } catch (err) {
      this.logger.error(`file="RejectClientInvitation" method="run" msg="OverAll: failed" error=${err}`);
      this.fail(500);
    }
  }

  validateRequest() {
    return new Promise((resolve, reject) => {
      if (!this.req.headers.orgoid || !this.req.headers.associateoid) {
        this.logger.error('file="RejectClientInvitation" method="validateRequest" msg="missing headers"');
        return reject(400);
      }
      if (!this.req.body.events[0].data.eventContext.invitation.invitationID) {
        this.logger.error('file="RejectClientInvitation" method="validateRequest" msg="missing invitationID"');
        return reject(400);
      }
      this.invitationID = this.req.body.events[0].data.eventContext.invitation.invitationID;
      return resolve();
    });
  }

  storeRejectInvitation() {
    return new Promise((resolve, reject) => {
      const params = {
        invitationid: this.invitationID,
        organizationOID: this.req.body.events[0].actor.organizationOID,
        set: this.model.mongoRejectInvitation
      };
      return this.rejectClientInvitation.run(params)
        .then(() => resolve())
        .catch((error) => reject(error));
    });
  }

  fail(code) {
    let statusCode = code;
    if (typeof code !== 'number') {
      statusCode = 500;
    }
    this.logger.error(`file="RejectClientInvitation" method="fail" msg="failed request with code" statusCode="${statusCode}" code="${code}" invitationID=${this.invitationID}`);
    return this.reply.failed(statusCode);
  }

  complete() {
    this.logger.info(`file="RejectClientInvitation" msg="success" invitationID=${this.invitationID}`);

    return this.reply.completed({
      invitation: {
        invitationStatusCode: {
          codeValue: 'rejected'
        }
      }
    }, 200);
  }
}


class RejectClientInvitation {
  constructor(deps) {
    this.deps = deps;
  }

  create() {
    return (req, event, reply) => {
      const handler = new Handler(this.deps, req, event, reply);
      handler.run();
    };
  }
}

module.exports = RejectClientInvitation;

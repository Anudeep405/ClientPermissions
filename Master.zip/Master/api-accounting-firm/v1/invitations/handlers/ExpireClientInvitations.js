'use strict';

class Handler {
  constructor(deps, req, reply) {
    this.req = req;
    this.reply = reply;

    this.logger = req.logger;
    this.config = deps.config;
    this.mongoRepo = deps.mongoRepo;
    this.mongodb = deps.mongodb;

    this.expireClientInvitations = new deps.ExpireClientInvitations({
      logger: this.logger,
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb
    });
  }

  run() {
    this.execute()
    .then((result) => this.complete(result))
    .catch((error) => this.fail(error));
  }

  execute() {
    return new Promise((resolve, reject) =>
      this.expireClientInvitations.run()
        .then((result) => resolve(result))
        .catch((error) => reject(error))
    );
  }

  fail(code) {
    let statusCode = code;
    if (typeof code !== 'number') {
      statusCode = 500;
    }
    this.logger.error(`file="ExpireClientInvitations" msg="failed request with code" statusCode=${statusCode} code=${code}`);
    return this.reply(undefined, statusCode);
  }

  complete(result) {
    if (!result) {
      this.reply(undefined, 204);
    } else {
      this.reply({
        invitationsCount: result
      }, 200);
    }
  }
}

class ExpireClientInvitations {
  constructor(deps) {
    this.deps = deps;
  }

  create() {
    return (req, event, reply) => {
      const handler = new Handler(this.deps, req, event, reply);
      handler.run();
    };
  }
}

module.exports = ExpireClientInvitations;

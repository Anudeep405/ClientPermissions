'use strict';

const ClientInvitationModel = require('../model/ClientInvitation');

class Handler {
  constructor(deps, req, reply) {
    this.req = req;
    this.reply = reply;
    this.logger = req.logger;
    this.dateTime = null;
    this.config = deps.config;

    this.getReminderInvitations = new deps.GetReminderInvitations({
      logger: this.logger,
      config: deps.config,
      mongoRepo: deps.mongoRepo,
      mongodb: deps.mongodb
    });

    this.updateReminderInvitations = new deps.UpdateReminderInvitations({
      logger: this.logger,
      config: deps.config,
      mongoRepo: deps.mongoRepo,
      mongodb: deps.mongodb
    });

    this.requestApi = new deps.RequestApi(this.logger, this.req);
    this.sendReminderInvitations = new deps.SendReminderInvitations({
      logger: this.logger,
      config: deps.config,
      mongoRepo: deps.mongoRepo,
      mongodb: deps.mongodb,
      requestApi: this.requestApi
    });
  }

  run() {
    this.dateTime = new Date().valueOf();
    this.createModel(this.req)
      .then(() => this.getReminders(this.dateTime))
      .then((result) => this.sendReminders(result))
      .then((result) => this.updateReminders(this.dateTime, result))
      .then((result) => this.complete(result))
      .catch((error) => this.fail(error));
  }

  createModel(req) {
    return new Promise((resolve, reject) => {
      try {
        this.model = new ClientInvitationModel(req.body, this.config);
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }

  getReminders(dTime) {
    return new Promise((resolve, reject) =>
      this.getReminderInvitations.run({ dateTime: dTime })
      .then((result) => resolve(result))
      .catch((error) => reject(error))
    );
  }

  sendReminders(result) {
    return new Promise((resolve, reject) => {
      // resolve(result);
      const emailInvitationBody = this.model.emailInvitationBody;
      return this.sendReminderInvitations.run({ reminders: result, emailInvitationBody })
        .then(() => resolve(result))
        .catch((error) => reject(error));
    });
  }

  updateReminders(dTime) {
    return new Promise((resolve, reject) =>
      this.updateReminderInvitations.run({ dateTime: dTime })
        .then((updateResult) => resolve(updateResult))
        .catch((error) => reject(error))
    );
  }

  fail(code) {
    let statusCode = code;
    if (typeof code !== 'number') {
      statusCode = 500;
    }
    this.logger.error(`file="ReminderClientInvitation" msg="failed request with code" statusCode=${statusCode} code=${code}`);
    return this.reply(undefined, statusCode);
  }

  complete(data) {
    if (!data) {
      this.reply(undefined, 204);
    } else {
      this.reply({
        reminder: { send: data.result.nModified }
      }, 200);
    }
  }
}

class ReminderClientInvitation {
  constructor(deps) {
    this.deps = deps;
  }

  create() {
    return (req, event, reply) => {
      const handler = new Handler(this.deps, req, event, reply);
      handler.run();
    };
  }
}

module.exports = ReminderClientInvitation;

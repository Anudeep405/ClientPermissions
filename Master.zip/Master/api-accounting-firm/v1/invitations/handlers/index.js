'use strict';

const ClientInvitationHandler = require('./CreateClientInvitation');
const AcceptClientInvitationHandler = require('./AcceptClientInvitation');
const RejectClientInvitationHandler = require('./RejectClientInvitation');
const GetClientInvitationsHandler = require('./GetClientInvitations');
const ReminderClientInvitation = require('./ReminderClientInvitation');
const ExpireClientInvitationsHandler = require('./ExpireClientInvitations');
const ExpireClientInvitationsAction = require('../actions/ExpireClientInvitations');
const StoreClientInvitation = require('../actions/StoreClientInvitation');
const AcceptClientInvitationAction = require('../actions/AcceptClientInvitation');
const RejectClientInvitationAction = require('../actions/RejectClientInvitation');
const UpdateReminderInvitations = require('../actions/UpdateReminderInvitations');
const GetReminderInvitations = require('../actions/GetReminderInvitations');
const SendReminderInvitations = require('../actions/SendReminderInvitations');
const GetClientInvitations = require('../actions/GetClientInvitations');
const LoadInvitation = require('../actions/LoadInvitation');
const RequestApi = require('../actions/RequestApi');


module.exports = class Handlers {
  constructor(deps) {
    this.config = deps.config;
    this.mongoRepo = deps.mongoRepo;
    this.mongodb = deps.mongodb;
  }

  createClientInvitation() {
    const handler = new ClientInvitationHandler({
      config: this.config,
      mongoRepo: this.mongoRepo,
      StoreClientInvitation,
      RequestApi
    });
    return handler.create();
  }

  acceptClientInvitation() {
    const handler = new AcceptClientInvitationHandler({
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb,
      LoadInvitation,
      AcceptClientInvitation: AcceptClientInvitationAction,
      RequestApi
    });
    return handler.create();
  }

  rejectClientInvitation() {
    const handler = new RejectClientInvitationHandler({
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb,
      RejectClientInvitation: RejectClientInvitationAction
    });
    return handler.create();
  }

  createGetClientInvitationsHandler() {
    const handler = new GetClientInvitationsHandler({
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb,
      GetClientInvitations
    });
    return handler.create();
  }

  sendReminderClientInvitationsHandler() {
    const handler = new ReminderClientInvitation({
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb,
      GetReminderInvitations,
      UpdateReminderInvitations,
      SendReminderInvitations,
      RequestApi
    });
    return handler.create();
  }

  expireClientInvitationsHandler() {
    const handler = new ExpireClientInvitationsHandler({
      config: this.config,
      mongoRepo: this.mongoRepo,
      mongodb: this.mongodb,
      ExpireClientInvitations: ExpireClientInvitationsAction,
      RequestApi
    });
    return handler.create();
  }
};

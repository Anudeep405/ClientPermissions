'use strict';

const InvitationsHandlers = require('./invitations/handlers');
const InvitationsConfig = require('./invitations/config');
const ClientHandlers = require('./client/handlers');
let ClientEnvConfig = require('./client/config');

module.exports = class Firm {
  constructor(globalDeps) {
    const invitationsConfig = new InvitationsConfig(globalDeps.config);
    const ClientConfig = new ClientEnvConfig(globalDeps.config);

    this.invitationsHandlers = new InvitationsHandlers({
      config: invitationsConfig,
      mongoRepo: globalDeps.mongoRepo,
      mongodb: globalDeps.mongodb
    });
      this.ClientHandlers = new ClientHandlers({
          config: ClientConfig,
          mongoRepo: globalDeps.mongoRepo,
          mongodb: globalDeps.mongodb
      });

    globalDeps.apiFactory.createNounApi(globalDeps.app, this.nouns);
    globalDeps.apiFactory.createEventApi(globalDeps.app, this.events);
  }

  get nouns() {
    return {
      routes: [{
        method: 'GET',
        path: '/accounting-firm/v1/ping',
        handler(req, reply) {
          reply({
            accountingFirm: 'pong'
          }, 200);
        }
      },
      {
        method: 'GET',
        path: '/accounting-firm/v1/client-access-invitations',
        handler: this.invitationsHandlers.createGetClientInvitationsHandler()
      },
      {
        method: 'GET',
        path: '/accounting-firm/v1/client-access-invitations/:invitationid',
        handler: this.invitationsHandlers.createGetClientInvitationsHandler()
      },
      {
        method: 'GET',
        path: '/accounting-firm/v1/send-invitations-reminder',
        handler: this.invitationsHandlers.sendReminderClientInvitationsHandler()
      },
      {
        method: 'GET',
        path: '/accounting-firm/v1/expire-invitations',
        handler: this.invitationsHandlers.expireClientInvitationsHandler()
      },
      {
        method: 'GET',
        path: '/accounting-firm/v1/non-run-client-permissions',
        handler: this.ClientHandlers.nonRunClientPermissionsHandler()
      }
    ] };
  }

  get events() {
    return {
      events: [{
        serviceCategoryCode: 'accounting-firm',
        eventNameCode: 'client-access-invitation.create',
        version: '1',
        handler: this.invitationsHandlers.createClientInvitation()
      }, {
        serviceCategoryCode: 'accounting-firm',
        eventNameCode: 'client-access-invitation.accept',
        version: '1',
        handler: this.invitationsHandlers.acceptClientInvitation()
      }, {
        serviceCategoryCode: 'accounting-firm',
        eventNameCode: 'client-access-invitation.reject',
        version: '1',
        handler: this.invitationsHandlers.rejectClientInvitation()
      }]
    };
  }
};


'use strict';

const sinon = require('sinon');
const expect = require('chai').expect;
const ClientPermission = require('../../actions/GetClientPermissions.js');
const util = require('util');

describe('Accounting Firm API Get Client Permissions tests', function() {
    const sandbox = sinon.sandbox.create();
    let deps = null;
    let mongoCollection;
    let validParams;

    const resolvePromise = function(output) {
        return new Promise((resolve, reject) => {
            resolve(output);
        });
    };

    function init() {
        validParams = {
            organizationOID: '1',
            associateOID: '2'
        };
        deps = {
            logger: {
                error: sandbox.stub(),
                info: sandbox.stub()
            },
            mongoRepo: {
                collection: sandbox.stub()
            },
            mongodb: {
                ObjectID: sandbox.stub()
            },
            config: {}
        };
        deps.mongodb.ObjectID.isValid = sandbox.stub();
        mongoCollection = {
            find: sandbox.stub()
        }
    }

    afterEach(() => {
        sandbox.restore();
    });


    describe('resolves promise on successful Mongo query', function(done) {
        let GetClientPermission;
        let result;
        let mongoResult;
        let emptyMongoResult;
        let promiseResult;

        before((done) => {
            init();

            mongoResult = [{something: true}];
            emptyMongoResult = [];
            deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
            mongoCollection.find.yields(null, mongoResult);

            GetClientPermission = new ClientPermission(deps);
            GetClientPermission.run(validParams)
                .then((result) => {
                    promiseResult = result;
                    done();
                })
                .catch((err) => {
                    done(err)
                })
        });

        it ('result is an array', () => {
            expect(promiseResult).to.be.a('array');
        });

    });


    describe('rejects promise on Mongo error', function(done) {
        let errorResult;
        let promiseResult;

        before((done) => {
            init();

            deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
            const mongoError = new Error('test');
            mongoCollection.find.yields(mongoError, null);


            let GetClientPermission = new ClientPermission(deps);
            GetClientPermission.run(validParams)
                .then((result) => {
                    done('resolved bad promise');
                })
                .catch((error) => {
                    errorResult = error;
                    done();
                })
        });

        it ('error is 500', () => {
            expect(errorResult).to.equal(500);
        });
    });

    describe('rejects promise on exception', function(done) {
        let errorResult;
        let promiseResult;
        before((done) => {
            init();
            deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
            mongoCollection.find.throws(new Error('test'));

            let GetClientPermission = new ClientPermission(deps);
            GetClientPermission.run(validParams)
                .then((result) => {
                    done('resolved bad promise');
                })
                .catch((error) => {
                    errorResult = error;
                    done();
                })
        });

        it ('error is 500', () => {
            expect(errorResult).to.equal(500);
        });

        it ('logs the error', () => {
            expect(deps.logger.error.getCall(0).args[0]).to.contain('file=GetClientPermissionsAction" msg="Mongo collection error" error=test');
        });
    });

    describe('returns 204 on empty mongo result', function(done) {
        let GetClientPermission;
        let errorResult = 'result not set';
        let mongoResult;
        let promiseResult;

        before((done) => {
            init();
            mongoResult = [];

            deps.mongoRepo.collection.returns(resolvePromise(mongoCollection));
            mongoCollection.find.yields(null, mongoResult);

            GetClientPermission = new ClientPermission(deps);

            GetClientPermission.run(validParams)
                .then((result) => {
                    errorResult = result;
                    done();
                })
                .catch(() => {
                    done('resolved bad promise');
                })
        });


        it ('error is 204 when no results', () => {
            expect(errorResult).to.equal(void(0));
        });

    });
});
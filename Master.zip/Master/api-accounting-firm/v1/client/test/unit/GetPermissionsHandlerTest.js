'use strict';

var sinon = require('sinon');
var expect = require('chai').expect;
var GetClientPermissions = require('../../handlers/ClientPermissions.js');
var util = require('util');

describe('Accounting Firm API Get Client Permission Handler tests', function() {

    const sandbox = sinon.sandbox.create();

    let deps;
    let validReq;

    const loggerStub = {
        error: sandbox.stub(),
        info: sandbox.stub()
    };

    const getClientPermissionsInstance = {
        run: sandbox.stub()
    };

    const resolvePromise = function(output) {
        return new Promise((resolve, reject) => {
            resolve(output);
        });
    }

    const rejectPromise = function(output) {
        return new Promise((resolve, reject) => {
            reject(output);
        });
    }

    function init() {
        deps = {
            mongoRepo: {
                collection: sandbox.stub()
            },
            config: {},
            GetClientPermissions: sandbox.stub()
        };

        deps.GetClientPermissions.returns(getClientPermissionsInstance);
    };

    afterEach(() => {
        sandbox.restore();
    });


    describe('handles a valid request', function(done) {
        let responseBody;
        let responseStatusCode;
        let getClientPermissionsResponse;

        before((done) => {
            init();

            let fakeReq = {
                params: {},
                headers: {
                    orgoid: '1',
                    associateoid: '2'
                },
                logger: loggerStub
            }

            getClientPermissionsResponse = { something: true};
            getClientPermissionsInstance.run.returns(resolvePromise(getClientPermissionsResponse));

            let getPermissions = new GetClientPermissions(deps);
            let handler = getPermissions.create();
            handler(fakeReq, function(response, code) {
                responseBody = response;
                responseStatusCode = code;
                done();
            });
        });

        it ('response code is 200', () => {
            expect(responseStatusCode).to.equal(200);
        });

        it ('response body is valid', () => {
            expect(responseBody.permissions).to.exist;
            expect(responseBody.permissions).to.equal(getClientPermissionsResponse);
        });

    });


    describe('handles when cannot all load Permissions', function(done) {
        let responseBody;
        let responseStatusCode;
        let getClientPermissionsResponse = 1000;

        before((done) => {
            init();

            let fakeReq = {
                params: {},
                headers: {
                    orgoid: '1',
                    associateoid: '2'
                },
                logger: loggerStub
            }

            getClientPermissionsInstance.run.returns(rejectPromise(getClientPermissionsResponse));

            let getPermissions = new GetClientPermissions(deps);
            let handler = getPermissions.create();
            handler(fakeReq, function(response, error) {
                responseBody = response;
                responseStatusCode = error;
                done();
            });
        });

        it ('response matches clientProvider error', () => {
            expect(responseStatusCode).to.equal(getClientPermissionsResponse);
        });

        it ('has no response body', () => {
            expect(responseBody).to.equal.undefined;
        });

    });

    describe('handles invalid request params', function(done) {
        let responseBody;
        let responseStatusCode;

        before((done) => {
            init();

            let fakeReq = {
                params: {},
                headers: {
                    orgoid: '1'
                },
                logger: loggerStub
            }
            let getPermissions = new GetClientPermissions(deps);
            let handler = getPermissions.create();
            handler(fakeReq, function(response, error) {
                responseBody = response;
                responseStatusCode = error;
                done();
            });
        });

        it ('status code is 400', () => {
            expect(responseStatusCode).to.equal(400);
        });

        it ('has no response body', () => {
            expect(responseBody).to.equal.undefined;
        });

    });





});
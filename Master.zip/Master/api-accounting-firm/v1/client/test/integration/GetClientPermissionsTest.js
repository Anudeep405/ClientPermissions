'use strict';

const expect = require('chai').expect;
const util = require('util');
const request = require('request');
const Config = require('../../config');
const config = new Config();
const accountingFirmDocs = require('@adp-sir/api-accounting-firm-docs').create();
const testIdentities = require('@adp-sir/ngcoreapi-int-test-identities');
const jsonschema = new (require('jsonschema').Validator)();
const copy = function(obj) {
    return JSON.parse(JSON.stringify(obj));
}


describe('Accounting Firm API: Get Permissions tests @ ' + config.Client_Permission_API_URL, () => {

    // let reportingRequestSample;
    let ResponseSchema;
    let permission1;
    let permission2;

    before((done) => {
        testIdentities.create('permissions', 'v1').then((identities) => {
            console.log(identities);

            permission1 = {
                accountantOOID: identities[0].organizationOID,
                accountantAOID: identities[0].associateOID,
                clientOOID: identities[0].clients[0].organizationOID,
                clientAOID: identities[0].clients[0].associateOID
            }
            permission2 = {
                accountantOOID: identities[0].organizationOID,
                accountantAOID: identities[0].associateOID,
                clientOOID: identities[0].clients[1].organizationOID,
                clientAOID: identities[0].clients[1].associateOID
            }

            accountingFirmDocs.getRequestSample(config.Client_Permission_API_PATH, (error, result) => {
                // reportingRequestSample = result;
                accountingFirmDocs.getResponseSchema('accounting-firm/v1/non-run-client-permissions', (error, result) => {
                    ResponseSchema = result;
                    done();
                });
            })
        });
    });

    describe('Makes successful request', () => {

        let response;

        before((done) => {
            const requestOptions = {
                uri: config.Client_Permission_API_URL,
                headers: {
                    orgoid: permission1.accountantOOID,
                    associateoid: permission1.accountantAOID,
                    'content-type': 'application/json',
                    'cache-control': 'no-cache'
                },
                json: true
            };
            request.get(requestOptions, (err, resp, bod) => {
                response = resp;
                done();
            });
        });

        it('status code is 200', () => {
            expect(response.statusCode).to.equal(200);
        });

        /*it('matches schema', () => {
         let validation = jsonschema.validate(response.body, ResponseSchema);
         expect(validation.valid, validation).to.be.true;
         });*/

        // TODO: test schema

        it ('invitations are sorted correctly', () => {

            function compare(res1, res2) {
                if (res1.invitationID < res2.invitationID) {
                    return 1;
                }
                if (res1.invitationID > res2.invitationID) {
                    return -1;
                }
                return 0;
            }

            const sortedResponse = copy(response.body.permissions).sort(compare);
            expect(JSON.stringify(sortedResponse)).to.equal(JSON.stringify(response.body.permissions));

        });

    });


    // describe('Makes unsuccessful request by invitation id', () => {
    //
    //     let response;
    //     const badInvitationID = '111111111';
    //
    //     before((done) => {
    //         const requestOptions = {
    //             uri: config.INVITATION_BY_INVITATIONID_URL.replace(':invitationid', badInvitationID),
    //             headers: {
    //                 orgoid: permission1.accountantOOID,
    //                 associateoid: permission1.accountantAOID,
    //                 'content-type': 'application/json',
    //                 'cache-control': 'no-cache'
    //             },
    //             params: {
    //                 invitationid: badInvitationID
    //             },
    //             json: true
    //         };
    //         request.get(requestOptions, (err, resp, bod) => {
    //             response = resp;
    //             done();
    //         });
    //     });
    //
    //     it('status code is 204', () => {
    //         expect(response.statusCode).to.equal(204);
    //     });
    //     /*
    //      it('matches schema', () => {
    //      let validation = jsonschema.validate(response.body, ResponseSchema);
    //      expect(validation.valid, validation).to.be.true;
    //      });
    //      */
    //     // TODO: test schema
    //
    // });

    describe('Handles invalid headers', () => {

        let response;

        before((done) => {
            const requestOptions = {
                uri: config.Client_Permission_API_URL,
                headers: {
                    'content-type': 'application/json',
                    'cache-control': 'no-cache'
                },
                json: true
            };
            request.get(requestOptions, (err, resp, bod) => {
                response = resp;
                done();
            });
        });

        it('status code is 400', () => {
            expect(response.statusCode).to.equal(400);
        });

        it('has no body', () => {
            expect(response.body).to.be.empty;
        });

    });

});

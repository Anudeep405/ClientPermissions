'use strict';

module.exports = class GetClientPermissions {
    constructor(deps) {
        this.logger = deps.logger;
        this.deps = deps;
        this.mongoRepo = deps.mongoRepo;
        this.objectID = deps.mongodb.ObjectID;
        this.collectionName = deps.config.Client_Permission_COLLECTION;

    }

    run(params) {
        const associateOID = params.associateOID;
        const organizationOID = params.organizationOID;

        const query = {
            'actor.organizationOID': organizationOID,
            'actor.associateOID': associateOID
        };
        return new Promise((resolve, reject) => {
            this.mongoRepo.collection(this.collectionName)
                .then(collection => {
                    collection.find(query, {}).toArray(function (err, resData) {
                        if (err) {
                            return reject(500);
                        }
                        return resolve(resData);
                    });
                })
                .catch((error) => {
                    this.logger.error(`file=GetClientPermissionsAction" msg="Mongo collection error" error=${(error || {}).message}`);
                    return reject(500);
                });
        });


    }
}
// {
//     "_id": "573e14369031cc0f00440a8f",
//     "actor": {
//         "organizationOID": "BHGBHGTYGDVVC"       // this is the ORGOID of the accounting firm
//         // should be an index
//     },
//     "clientPermissions": [{
//         "organizationOID": "OOOKDJNCHDGB"      // this is the ORGOID of the client
//         "sorCode": "WFN"                                    // what is the client’s product
//         "accessPermissionHistory": [{
//             “effectiveDateTime”: “2015-06-30T07:31:47.725841-04:00”,    // this is when the access was granted
//             “accessPermissions”: {
//             "payrollReports": true,           // this is the access permission info
//             "payrollApprove": false,
//             "generalLedger": true,
//             "taxFormsView": true
//         },
//             "responseActor": {
//         "formattedNameAtTimeOfResponse": "Maria Pizzo",    // this is the info of the user on
//         "associateOID": "OOIKJNHBGFFFF",                                 // the client who granted the permissions
//         "organizationOID": "OOOKDJNCHDGB"
//     },
// },
//     {
// “effectiveDateTime”: “2014-03-13T07:31:47.725841-04:00”,    // this is when the access was granted
// “accessPermissions”: {
//     "payrollReports": fase,           // this is the access permission info
//         "payrollApprove": false,
//         "generalLedger": false,
//         "taxFormsView": true
// },
// "responseActor": {
//     "formattedNameAtTimeOfResponse": "Vera Lima",    // this is the info of the user on
//         "associateOID": "JNJNJNJNJNJNJNJ",                                 // the client who granted the permissions
//         "organizationOID": "OOOKDJNCHDGB"
// },
// }]
// }]
// }
//
// };



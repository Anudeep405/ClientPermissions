'use strict';

const ClientPermissionsHandler = require('./ClientPermissions');
const GetClientPermissions = require('../actions/GetClientPermissions');

module.exports = class Handlers {
    constructor(deps) {
        this.config = deps.config;
        this.mongoRepo = deps.mongoRepo;
        this.mongodb = deps.mongodb;
    }


    nonRunClientPermissionsHandler() {
        const handler = new ClientPermissionsHandler({
            config: this.config,
            mongoRepo: this.mongoRepo,
            mongodb: this.mongodb,
            GetClientPermissions
        });
        return handler.create();
    }

};

'use strict';

class Handler {
    constructor(deps, req, reply) {
        this.req = req;
        this.reply = reply;

        this.logger = req.logger;
        this.config = deps.config;
        this.mongoRepo = deps.mongoRepo;
        this.mongodb = deps.mongodb;

        this.GetClientPermissions = new deps.GetClientPermissions({
            logger: this.logger,
            config: this.config,
            mongoRepo: this.mongoRepo,
            mongodb: this.mongodb
        });
    }

    run() {
        this.validateRequest()
            .then(() => this.ClientPermissions())
            .then((result) => this.complete(result))
            .catch((error) => this.fail(error));
    }

    ClientPermissions() {
        return new Promise((resolve, reject) => {
            // const deps = {
            //   logger: this.logger,
            //   mongoRepo: this.mongoRepo,
            //   config: this.config
            // };

            const params = {
                organizationOID: this.req.headers.orgoid,
                associateOID: this.req.headers.associateoid
            };

            return this.GetClientPermissions.run(params)
                .then((result) => resolve(result))
                .catch((error) => reject(error));
        });
    }

    validateRequest() {
        return new Promise((resolve, reject) => {
            if (!this.req.headers.associateoid || !this.req.headers.orgoid) {
                return reject(400);
            }
            return resolve();
        });
    }

    fail(code) {
        let statusCode = code;
        if (typeof code !== 'number') {
            statusCode = 500;
        }
        this.logger.error(`file="GetClientPermissions" method="fail" msg="failed request with code" statusCode="${statusCode}" code="${code}"`);
        return this.reply(undefined, statusCode);
    }

    complete(result) {
        if (!result) {
            this.reply(undefined, 204);
        } else {
            this.reply({
                permissions: result
            }, 200);
        }
    }
}

class ClientPermissions {
    constructor(deps) {
        this.deps = deps;
    }

    create() {
        return (req, event, reply) => {
            const handler = new Handler(this.deps, req, event, reply);
            handler.run();
        };
    }
}

module.exports = ClientPermissions;

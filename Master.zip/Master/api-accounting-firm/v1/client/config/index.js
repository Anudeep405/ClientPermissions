'use strict';

class Config {

    constructor(globalConfig) {
        this.Client_Permission_COLLECTION = 'ApiClientPermissions';

        let apiServicesHost;
        if (globalConfig) {
            apiServicesHost = globalConfig.endpoints.apiServices;
        }
        this.API_HOST = (process.env.TARGET_URI || apiServicesHost) + '/i/api/';

        this.Client_Permission_API_PATH = '/accounting-firm/v1/non-run-client-permissions';
        this.Client_Permission_API_URL = this.API_HOST + this.Client_Permission_API_PATH;

    }
}

module.exports = Config;

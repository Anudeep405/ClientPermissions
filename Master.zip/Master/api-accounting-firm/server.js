'use strict'

const Firm = require('./v1');   
const ApiBootstrap = require('@adp-sir/ngcoreapi-bootstrap');
const apiBootstrap = new ApiBootstrap('accounting-firm', Firm);
apiBootstrap.create();
